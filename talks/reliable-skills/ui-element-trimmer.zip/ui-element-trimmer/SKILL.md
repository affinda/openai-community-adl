---
name: ui-element-trimmer
description: Isolate a captured UI element from a screenshot into a pixel-faithful transparent PNG with a clean replacement drop shadow. Use for modals, dialogs, menus, popovers, tooltips, cards, panels, toasts and similar interface surfaces when the user asks to trim, crop, extract, clean up, remove surrounding screenshot/background, preserve rounded corners or borders, or add a subtle shadow. Always use the untouched original screenshot, deterministic masking, strict per-side geometry checks, all-sided shadow validation and mandatory visual QA. For dark-mode captures, preserve a rounded background container around the complete button and label, and shadow that container. When only boundary geometry is uncertain, inspect the original shape and colour and provide a clearly labelled candidate for user judgement. Never redraw or regenerate the UI.
---

# UI Element Trimmer

Create a clean transparent PNG from a screenshot while preserving the captured UI at its original scale. Reliability is more important than speed.

## Acceptance standard

Treat this as the target quality:

- preserve the complete visible UI surface, including its outer border and antialiased rounded corners;
- in source-surface modes, crop exactly to the outer UI surface, never to an inner border, highlight or content edge;
- in dark-container mode, choose an enclosing boundary with background spacing around the full content; it need not be an existing screenshot edge;
- in source-surface modes, remove the original page/background and captured shadow completely;
- for dark-mode captures, retain a deliberate area of the original dark background inside a new rounded container, including the complete button/icon and any associated text; remove screenshot pixels outside that container;
- place the isolated UI on a new RGBA canvas with genuine alpha transparency;
- generate a fresh soft shadow that is visible around **top, bottom, left and right** and fades to zero before the canvas edge;
- preserve text, icons, spacing, colour, dimensions and scale;
- leave a transparent guard band outside the new shadow.

A visibly clipped or incorrectly placed boundary is a failure. A low-confidence boundary check alone is an uncertainty to inspect and, if unresolved, present for user judgement. A result with shadow only below the UI is a failure. A PNG that merely contains some transparent pixels is not sufficient.

If the user supplies a good example, treat it as the visual acceptance reference for crop cleanliness, transparency and shadow treatment. Do not use pixels from the reference unless it is also the requested source image.

## Absolute source rule

Every attempt MUST start from the untouched original screenshot supplied by the user.

- Never process a previous output from this skill.
- Never trim a trim.
- The renderer tags generated PNGs and refuses them as normal input.
- If the original screenshot clips the target surface, do not invent missing pixels.

## Required workflow

### 1. Inspect the untouched source

Classify the target:

- **Dark-mode capture**: default to `dark-container`. Keep the button/icon, its associated label (for example, Home), and some original background together inside one rounded rectangle. Even a lone circular Add button gets an enclosing background container. Do not flood-remove the dark background or make a separate text silhouette. Use a different treatment only when the user explicitly requests it.

- **Rounded surface**: modal, dialog, menu, popover, tooltip, rounded card or panel. Default to `rounded-card`.
- **Rectangular surface**: square-cornered panel or region.
- **Irregular contrasting element**: use `flood` only when the surrounding background is clearly separable.

If several unrelated elements could be the target and the user has not identified one, ask which element to isolate.

### 2. Analyse geometry before rendering

For every source, run the analysis command first. For dark-container mode, use the overlay to identify the full content, then choose enclosing coordinates manually; an automatically detected button boundary is not the container boundary:

```bash
python scripts/trim_ui_element.py INPUT.png OUTPUT.png --analyse-only
```

This writes:

- `OUTPUT.analysis.json`
- `OUTPUT.analysis.png`

Open the analysis overlay. For source-surface modes, Candidate 1 is usable only when it follows the **complete outer surface** on all four sides and around all four corners. It must not sit on an inner border or remove a visible outer border.

If automatic geometry is not clearly correct, use explicit source coordinates:

```bash
python scripts/trim_ui_element.py INPUT.png OUTPUT.png \
  --mode rounded-card --crop x1,y1,x2,y2 --corner-radius R
```

`x2` and `y2` are exclusive.

For source-surface modes, do not choose explicit coordinates merely because the automatic result failed. Inspect the untouched source and use evidence from the visible boundary. For dark-container mode, inspect the full content and available surrounding background.

### Dark-container geometry

Choose `--content-bounds x1,y1,x2,y2` in original source coordinates to cover every intended button/icon/label pixel, including antialiasing. Choose a larger `--crop` containing background on every side, with balanced spacing and no unrelated neighbouring UI. Aim for 4-8 px at native screenshot scale for small controls; scale the spacing sensibly for larger captures. Keep at least 2 px of fully opaque background outside the content bounds, including near rounded corners. Do not enlarge, recolour or invent the retained background.

Choose a modest radius, usually 4-8 px for small controls and smaller than half the shorter container dimension. The container must retain a visible margin inside the original screenshot. If the available capture lacks room, request a wider capture rather than clipping a label or synthesising background.

```bash
python scripts/trim_ui_element.py INPUT.png OUTPUT.png \
  --mode dark-container --crop 3,3,52,64 \
  --content-bounds 10,9,46,59 --corner-radius 4
```

These coordinates illustrate the supplied small Home capture; inspect each new source before choosing coordinates. The renderer preserves all content and background inside the opaque container, rounds only its outside corners, and generates the replacement shadow from the single containing shape. Any existing control styling inside the container remains as captured.

### 3. Freeze geometry for the attempt

Once bounds and radius are chosen, keep them fixed for that attempt.

If a side is wrong, discard the output and restart from the original screenshot with corrected geometry. Never shave pixels from a generated output.

### 4. Render onto a blank transparent canvas

For dark captures, run the `dark-container` command above with the inspected geometry. For other captures, run the normal renderer:

```bash
python scripts/trim_ui_element.py INPUT.png OUTPUT.png --mode rounded-card
```

The renderer must:

1. crop source pixels only from the chosen UI bounds;
2. build the UI alpha mask;
3. remove all captured pixels outside that mask;
4. decontaminate only the narrow antialiased boundary band;
5. preserve fully opaque source pixels exactly, including straight outer borders;
6. place the mask onto an **expanded padded canvas before blurring it**;
7. generate the replacement shadow from that expanded mask;
8. composite the clean UI above the new shadow;
9. zero RGB anywhere alpha is zero.

### Critical shadow invariant

Never blur an element-sized mask and then paste it onto a larger canvas. That clips the blur at the UI bounds and removes the shadow from top, left and right.

Always:

```text
blank padded alpha canvas
â†’ place UI mask at padded position + shadow offset
â†’ blur the full padded canvas
â†’ apply shadow opacity
â†’ composite UI above it
```

### 5. Check rendering and distinguish boundary uncertainty

The render command writes `OUTPUT.manifest.json`. Failures involving content fidelity, transparency, shadow, clipping or an invalid container mean reject the result. A source-boundary geometry failure alone may produce a review candidate using the workflow below; it must remain marked as an automated failure.

Checks include:

- correct RGBA output and dimensions;
- real transparent pixels plus a clear transparent guard band;
- no source RGB in the shadow or transparent region;
- shadow present and smoothly fading on all four sides;
- left/right shadow balance when horizontal offset is zero;
- source pixels unchanged through the safe interior;
- the first two straight-edge pixel bands preserved exactly from the source;
- in source-surface modes, each selected crop side is the local outer boundary, not a nearby inner/outer edge;
- in dark-container mode, the declared rounded rectangle mask matches the chosen geometry and fully encloses the content bounds plus 2 px of opaque background;
- source-surface rounded corners follow the source edge; chosen container corners preserve the complete content;
- the UI is not flush with the original screenshot edge.

### 6. Run the independent verifier

Always run:

```bash
python scripts/verify_ui_element.py \
  --source INPUT.png \
  --output OUTPUT.png \
  --manifest OUTPUT.manifest.json \
  --qa-dir OUTPUT_QA
```

It writes:

- `verification.json`
- `qa_backgrounds.png`
- `qa_edges.png`
- `qa_alpha.png`
- `qa_source_boundary.png`

`verification.json: pass=true` means **automated checks passed only**. It is never sufficient by itself. The report deliberately includes `visual_review_required: true`.

### 7. Mandatory visual QA

Open **all four** QA images before returning the PNG.

#### `qa_source_boundary.png`

Check the selected source boundary first. For dark-container mode, the red outline is a deliberately chosen enclosing boundary, not an existing UI border. Confirm that the full button and associated text sit comfortably inside it, that original background spacing remains on all sides, and that no unrelated content or corners cut through the intended content. Do not reject a container merely because its boundary crosses uniform original background.

For source-surface modes, reject if:

- any red boundary line is inside the visible UI border;
- a source-surface side is one pixel too tight or too loose, or a dark container clips content or lacks background spacing;
- the line follows an internal divider, inner stroke or highlight rather than the outer surface;
- the rounded corners do not match the actual source geometry.

#### `qa_backgrounds.png`

Inspect white, black, mid-grey and checkerboard views. Reject if:

- source page/background remains outside the selected surface or dark container; intentional dark background inside the container must remain;
- the outside region behaves as opaque rather than transparent;
- there is a halo or old-background colour around an edge;
- the replacement shadow is absent on any side;
- the shadow looks doubled, hard-cut or uneven.

#### `qa_edges.png`

Inspect every corner and straight edge. Reject if:

- a corner is clipped, flattened or the wrong radius;
- a straight edge is trimmed too tightly;
- the shadow meets the UI abruptly instead of fading naturally.

#### `qa_alpha.png`

Black must represent genuinely transparent canvas. The UI must be solid white through the opaque surface. A dark container must be one solid rounded rectangle, including background between the button and label. The shadow must be a smooth grey field around the outer shape on all sides with no separate text-shaped or icon-shaped detail.

### Boundary uncertainty and user judgement

If the geometry check is unsure, return to the untouched original before changing coordinates. Inspect the actual surface colour against the surrounding page, its straight sides and all rounded corners. Check that the selected mask follows the original shape rather than an inner highlight or text edge. Compare source colour samples on each side and the source-boundary overlay. Low contrast and a transition spread across several blurred pixels can make a plausible shape fail exact-edge thresholds; do not treat this alone as proof of a bad crop.

If shape/colour inspection supports a plausible crop but an automated boundary pass remains unavailable, render a review candidate:

```bash
python scripts/trim_ui_element.py INPUT.png OUTPUT-review.png \
  --mode rounded-card --crop x1,y1,x2,y2 --corner-radius R \
  --review-boundary
```

This requires inspected explicit coordinates and a radius. It can save a candidate only when the source-boundary geometry check is the sole failed renderer check. It refuses clipping, content loss, fidelity failures, bad transparency or shadow failures. The manifest and PNG retain `release_status: needs-user-review` and `automated_pass: false`. The manifest also records source-only inside/outside colour samples for review; these do not establish an exact boundary.

Run the independent verifier and inspect all four QA images. Its exit code remains non-zero when the boundary check fails. `review_eligible: true` permits sharing the candidate for human judgement only if every other independent check passes and visual review finds no definite defect. Do not use this option to override a visibly wrong edge or a known defect. If the independent verifier passes, the normal automated/visual workflow applies.

Show the candidate inline and provide its PNG download link. Say briefly that the shape and colour were checked, the exact boundary remains uncertain, and the image is for the user's decision. Include a source-boundary comparison when it helps. Do not withhold an otherwise sound candidate merely because the boundary detector is uncertain. Do not claim an automated pass or describe the result as fully verified.

When the user accepts the actual candidate, treat it as user-approved and preserve that decision in the conversation. Acceptance does not change the failed automated result. A judgement about an earlier image is not approval of an unseen retry. Ask for a sharper capture only if the user rejects the candidate or the available source cannot support a sound review image.

### Release states

- **Automated and visually checked:** every automated check passes and all four QA views have been personally inspected.
- **For user review:** only boundary geometry remains uncertain, the independent verifier reports `review_eligible: true`, and shape/colour inspection plus visual QA support a plausible result.
- **User-approved:** the user accepts the supplied review image; retain its actual automated status.
- **Rejected:** any definite visual defect or any non-boundary check fails. Do not provide it as an acceptable result.

### 8. Retry method

For a definite defect or a non-boundary automated failure, retry as follows. For boundary-only uncertainty, use the review workflow above:

1. discard the generated result;
2. return to the untouched original screenshot;
3. change only the geometry/radius supported by evidence;
4. rerender from scratch;
5. rerun the verifier;
6. reopen all QA views.

Make up to three evidence-based attempts. Do not perform arbitrary repeated one-pixel trims. If only exact boundary confidence remains unresolved, provide the review candidate described above. If other requirements fail, stop and explain what prevents a sound result.

## Modes

### Dark container

Use `--mode dark-container` with explicit `--crop`, `--content-bounds` and `--corner-radius` for dark-mode captures. See Dark-container geometry above. Background inside the chosen rounded shape is intentional and preserved. The shadow belongs to that shape. Source-edge detection is replaced by content-enclosure and mask-geometry checks; fidelity, transparency, shadow and visual-QA requirements still apply.

### Rounded card

Use `--mode rounded-card` for most light-on-light captured UI.

Automatic detection favours a coherent outer rectangle over internal dividers. The verifier independently compares each chosen side with nearby Â±3 px alternatives and rejects one-pixel inward/outward errors when the source boundary evidence supports rejection.

### Rectangle

```bash
python scripts/trim_ui_element.py INPUT.png OUTPUT.png --mode rectangle
```

### Flood

Use only for a truly irregular element on a clearly contrasting surrounding background. Do not use flood mode for dark-mode controls unless the user explicitly requests a background-free silhouette:

```bash
python scripts/trim_ui_element.py INPUT.png OUTPUT.png \
  --mode flood --crop x1,y1,x2,y2 --threshold 18
```

If flood mode removes light UI content or retains surrounding page content, stop and use geometric isolation or request a cleaner source.

## Shadow standard

Default replacement shadow:

- x offset: `0 px`
- y offset: `3 px`
- blur radius: `6 px`
- opacity: `42/255`
- colour: neutral black
- padding: calculated automatically with enough transparent guard band to prevent clipping

Change these only when the user explicitly requests a different treatment.

## Pixel-fidelity rule

The screenshot is already flattened, so antialiased edge pixels can contain colours from the old background. Preserve the fully opaque source exactly. Reconstruct only the partially covered edge band from neighbouring interior colours so transparency does not create a halo.

Never alter interior text, icons, colours, spacing, gradients or layout.

## Hard failure conditions

Do not return a file when:

- the target is clipped by the source screenshot;
- target geometry has a definite defect or is too ambiguous to support even a plausible user-review candidate;
- any side appears too tight or too loose;
- the visible border is lost or changed;
- shadow is missing on any side;
- transparency or guard-band checks fail;
- any source detail appears in the new shadow region;
- any non-boundary automated check fails; a boundary-only uncertainty uses the user-review workflow;
- visual QA reveals a definite defect; uncertainty about the exact boundary must be disclosed for user judgement;
- the only way to proceed would be to redraw or invent UI pixels.

## Regression maintenance

After changing either bundled script, run:

```bash
python scripts/self_test.py
```

The regression suite includes:

- light and dark rounded surfaces;
- square panels;
- nested/internal dividers;
- near-edge captures;
- a large bordered Microsoft-style modal analogous to the real failure case;
- all-sided shadow and transparent guard-band checks;
- outer-border fidelity checks;
- one-pixel crop-error rejection on every side;
- deliberate recreation of the old clipped-shadow algorithm, which the verifier must reject;
- irregular flood mode;
- dark containers retaining a complete button, label and background, with a single outer shadow;
- rejection of missing content bounds, insufficient spacing and corners cutting content;
- boundary-only review candidates remaining marked as automated failures;
- review mode rejecting non-boundary defects.

Do not package a changed version unless the full regression suite passes.

## Final response

Return the PNG inline with a download link and a short, accurate status: checked, for user review, or user-approved. A boundary-uncertain candidate must be explicitly labelled for user judgement. Never claim automated verification passed when it did not. Provide the original-shape comparison when helpful.
