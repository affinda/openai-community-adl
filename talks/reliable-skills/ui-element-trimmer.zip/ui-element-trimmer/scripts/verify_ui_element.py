#!/usr/bin/env python3
"""Independent verification and visual-QA sheet generator for UI Element Trimmer.

Requires Pillow and NumPy only.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

GENERATED_TAG = "ui_element_trimmer_generated"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def add_test(tests: dict, name: str, passed: bool, value) -> None:
    tests[name] = {"pass": bool(passed), "value": value}


def checkerboard(size: tuple[int, int], tile: int = 16) -> Image.Image:
    w, h = size
    y, x = np.indices((h, w))
    pattern = ((x // tile + y // tile) % 2).astype(np.uint8)
    light = np.array([232, 232, 232], dtype=np.uint8)
    dark = np.array([184, 184, 184], dtype=np.uint8)
    arr = np.where(pattern[:, :, None] == 0, light, dark)
    return Image.fromarray(arr, mode="RGB").convert("RGBA")


def composite_on(result: Image.Image, background: Image.Image) -> Image.Image:
    bg = background.convert("RGBA")
    bg.alpha_composite(result)
    return bg.convert("RGB")


def label_panel(image: Image.Image, label: str) -> Image.Image:
    bar = 24
    out = Image.new("RGB", (image.width, image.height + bar), "white")
    out.paste(image, (0, bar))
    draw = ImageDraw.Draw(out)
    draw.text((6, 5), label, fill="black")
    return out


def fit_thumbnail(image: Image.Image, max_w: int = 900, max_h: int = 750) -> Image.Image:
    scale = min(1.0, max_w / image.width, max_h / image.height)
    if scale >= 1.0:
        return image
    size = (max(1, int(round(image.width * scale))), max(1, int(round(image.height * scale))))
    return image.resize(size, Image.Resampling.LANCZOS)


def make_background_qa(result: Image.Image, path: Path) -> None:
    size = result.size
    backgrounds = [
        ("White", Image.new("RGBA", size, (255, 255, 255, 255))),
        ("Black", Image.new("RGBA", size, (0, 0, 0, 255))),
        ("Mid-grey", Image.new("RGBA", size, (128, 128, 128, 255))),
        ("Checkerboard", checkerboard(size)),
    ]
    panels = [label_panel(fit_thumbnail(composite_on(result, bg)), label) for label, bg in backgrounds]
    cell_w = max(p.width for p in panels)
    cell_h = max(p.height for p in panels)
    sheet = Image.new("RGB", (cell_w * 2, cell_h * 2), "white")
    for idx, panel in enumerate(panels):
        x = (idx % 2) * cell_w
        y = (idx // 2) * cell_h
        sheet.paste(panel, (x, y))
    path.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(path, "PNG")


def geometry_alignment_metrics(source: Image.Image, crop: list[int], radius: int, mode: str) -> dict:
    """Independently check that each chosen side is the local outer boundary.

    This verifier intentionally uses boundary-step comparisons rather than the
    renderer's candidate scoring. A crop one or two pixels inside the true
    surface should therefore fail even when it still sits on a strong gradient.
    """
    rgb = np.asarray(source.convert("RGB"), dtype=np.uint8).astype(np.float32)
    dx = np.sqrt(np.sum((rgb[:, 1:, :] - rgb[:, :-1, :]) ** 2, axis=2))
    dy = np.sqrt(np.sum((rgb[1:, :, :] - rgb[:-1, :, :]) ** 2, axis=2))
    h, w, _ = rgb.shape
    l, t, r, b = crop
    exclude_y = max(5, int((b - t) * 0.06), radius + 2 if radius else 5)
    exclude_x = max(5, int((r - l) * 0.06), radius + 2 if radius else 5)
    ya, yb = min(b, t + exclude_y), max(t, b - exclude_y)
    xa, xb = min(r, l + exclude_x), max(l, r - exclude_x)

    def score(a: np.ndarray) -> float:
        return float(np.median(np.log1p(a))) if a.size else 0.0

    def side_vertical(boundary: int, left_side: bool) -> dict:
        nearby = {}
        for off in range(-3, 4):
            x = boundary + off
            if 1 <= x < w:
                nearby[off] = score(dx[ya:yb, x - 1])
        selected = nearby.get(0, 0.0)
        best_off = max(nearby, key=nearby.get) if nearby else 99
        best = nearby.get(best_off, 0.0)
        x = boundary
        if 1 <= x < w:
            cross = dx[ya:yb, x - 1]
            inner = dx[ya:yb, x] if left_side and x < w - 1 else dx[ya:yb, x - 2] if (not left_side and x >= 2) else np.zeros_like(cross)
            outer = dx[ya:yb, x - 2] if left_side and x >= 2 else dx[ya:yb, x] if (not left_side and x < w - 1) else np.zeros_like(cross)
            dominance = float(np.mean((cross >= 6.0) & (cross >= np.maximum(inner, outer) * 1.20 + 1.0))) if cross.size else 0.0
        else:
            dominance = 0.0
        return {
            "best_nearby_offset": int(best_off),
            "selected_to_best_ratio": float(selected / max(best, 1e-6)),
            "dominance_fraction": dominance,
        }

    def side_horizontal(boundary: int, top_side: bool) -> dict:
        nearby = {}
        for off in range(-3, 4):
            y = boundary + off
            if 1 <= y < h:
                nearby[off] = score(dy[y - 1, xa:xb])
        selected = nearby.get(0, 0.0)
        best_off = max(nearby, key=nearby.get) if nearby else 99
        best = nearby.get(best_off, 0.0)
        y = boundary
        if 1 <= y < h:
            cross = dy[y - 1, xa:xb]
            inner = dy[y, xa:xb] if top_side and y < h - 1 else dy[y - 2, xa:xb] if (not top_side and y >= 2) else np.zeros_like(cross)
            outer = dy[y - 2, xa:xb] if top_side and y >= 2 else dy[y, xa:xb] if (not top_side and y < h - 1) else np.zeros_like(cross)
            dominance = float(np.mean((cross >= 6.0) & (cross >= np.maximum(inner, outer) * 1.20 + 1.0))) if cross.size else 0.0
        else:
            dominance = 0.0
        return {
            "best_nearby_offset": int(best_off),
            "selected_to_best_ratio": float(selected / max(best, 1e-6)),
            "dominance_fraction": dominance,
        }

    sides = {
        "left": side_vertical(l, True),
        "right": side_vertical(r, False),
        "top": side_horizontal(t, True),
        "bottom": side_horizontal(b, False),
    }
    side_pass = all(
        abs(v["best_nearby_offset"]) <= 1
        and v["selected_to_best_ratio"] >= 0.90
        and v["dominance_fraction"] >= 0.55
        for v in sides.values()
    )

    # Rounded-corner sanity check: selected radius must continue to intersect a
    # strong corner ridge. This is deliberately simpler than the renderer fit.
    corner_score = 1.0
    if mode == "rounded-card" and radius > 0:
        import math
        grad = np.zeros((h, w), dtype=np.float32)
        grad[:, 1:] = np.maximum(grad[:, 1:], dx)
        grad[:, :-1] = np.maximum(grad[:, :-1], dx)
        grad[1:, :] = np.maximum(grad[1:, :], dy)
        grad[:-1, :] = np.maximum(grad[:-1, :], dy)
        arcs = [
            (l + radius - 0.5, t + radius - 0.5, 180.0, 270.0),
            (r - radius - 0.5, t + radius - 0.5, 270.0, 360.0),
            (l + radius - 0.5, b - radius - 0.5, 90.0, 180.0),
            (r - radius - 0.5, b - radius - 0.5, 0.0, 90.0),
        ]
        vals = []
        for cx, cy, a0, a1 in arcs:
            for angle in np.linspace(a0, a1, 36):
                rad = math.radians(float(angle))
                x = int(round(cx + radius * math.cos(rad)))
                y = int(round(cy + radius * math.sin(rad)))
                if 0 <= x < w and 0 <= y < h:
                    vals.append(float(grad[y, x]))
        arr = np.asarray(vals, dtype=np.float32)
        corner_score = float(np.mean(arr >= 8.0)) if arr.size else 0.0

    passed = side_pass and (corner_score >= 0.70 if mode == "rounded-card" and radius > 0 else True)
    return {"pass": bool(passed), "sides": sides, "corner_edge_fraction": corner_score}


def shadow_distribution_metrics(alpha: np.ndarray, padding: int, ew: int, eh: int, blur: int, ox: int, oy: int) -> dict:
    """Verify all-sided shadow presence and a clean fade without reproducing rendering logic."""
    H, W = alpha.shape
    l, t, r, b = padding, padding, padding + ew, padding + eh
    xa, xb = l + max(4, ew // 8), r - max(4, ew // 8)
    ya, yb = t + max(4, eh // 8), b - max(4, eh // 8)
    xa, xb = min(xa, r), max(xb, l)
    ya, yb = min(ya, b), max(yb, t)
    max_depth = max(3, min(padding - 1, blur * 4 + max(abs(ox), abs(oy)) + 2))

    def row_profile(start: int, step: int) -> list[float]:
        vals = []
        for d in range(max_depth):
            y = start + step * d
            if not (0 <= y < H) or xb <= xa:
                break
            vals.append(float(np.mean(alpha[y, xa:xb])))
        return vals

    def col_profile(start: int, step: int) -> list[float]:
        vals = []
        for d in range(max_depth):
            x = start + step * d
            if not (0 <= x < W) or yb <= ya:
                break
            vals.append(float(np.mean(alpha[ya:yb, x])))
        return vals

    profiles = {
        "top": row_profile(t - 1, -1),
        "bottom": row_profile(b, 1),
        "left": col_profile(l - 1, -1),
        "right": col_profile(r, 1),
    }

    def extent(values: list[float]) -> int:
        reach = 0
        for i, value in enumerate(values, start=1):
            if value > 0.0:
                reach = i
        return reach

    def fade(values: list[float]) -> tuple[bool, float]:
        positive = [v for v in values if v > 0.0]
        if blur <= 0:
            return True, 0.0
        if len(positive) < 2:
            return False, positive[-1] if positive else 0.0
        tail = positive[-1]
        far = values[min(len(values) - 1, max(1, len(values) // 2))]
        return bool(tail <= 2.5 and far <= max(values[0] * 0.65, 4.0)), float(tail)

    extents = {name: extent(v) for name, v in profiles.items()}
    near_means = {name: (v[0] if v else 0.0) for name, v in profiles.items()}
    fades = {name: fade(v) for name, v in profiles.items()}
    min_extent = max(2, blur // 2) if blur else 0
    present = all(v >= min_extent for v in extents.values()) and all(v >= 0.5 for v in near_means.values())
    horizontal_extent_balance = True
    horizontal_alpha_balance = True
    if ox == 0 and blur > 0:
        horizontal_extent_balance = abs(extents["left"] - extents["right"]) <= 2
        ratio = min(near_means["left"], near_means["right"]) / max(near_means["left"], near_means["right"], 1e-6)
        horizontal_alpha_balance = ratio >= 0.80
    fade_pass = all(ok for ok, _tail in fades.values())
    return {
        "pass": bool(present and horizontal_extent_balance and horizontal_alpha_balance and fade_pass),
        "extents": extents,
        "near_edge_mean_alpha": near_means,
        "tail_mean_alpha": {name: tail for name, (_ok, tail) in fades.items()},
        "minimum_required_extent": int(min_extent),
        "horizontal_extent_balance": bool(horizontal_extent_balance),
        "horizontal_alpha_balance": bool(horizontal_alpha_balance),
        "fade_pass": bool(fade_pass),
    }

def straight_edge_preservation_metrics(source_crop: np.ndarray, output_crop: np.ndarray, mask_alpha: np.ndarray, radius: int, mode: str) -> dict:
    """Check the outer straight border itself, which interior-fidelity tests omit."""
    h, w, _ = source_crop.shape
    if h < 3 or w < 3:
        return {"pass": False, "reason": "element too small for edge-fidelity check"}
    exclude = max(3, radius + 2 if mode in {"rounded-card", "dark-container"} and radius > 0 else 3)
    xa, xb = min(w, exclude), max(0, w - exclude)
    ya, yb = min(h, exclude), max(0, h - exclude)
    thickness = min(2, h, w)
    samples = {}
    if xb > xa:
        samples["top"] = (source_crop[:thickness, xa:xb], output_crop[:thickness, xa:xb], mask_alpha[:thickness, xa:xb])
        samples["bottom"] = (source_crop[h-thickness:h, xa:xb], output_crop[h-thickness:h, xa:xb], mask_alpha[h-thickness:h, xa:xb])
    if yb > ya:
        samples["left"] = (source_crop[ya:yb, :thickness], output_crop[ya:yb, :thickness], mask_alpha[ya:yb, :thickness])
        samples["right"] = (source_crop[ya:yb, w-thickness:w], output_crop[ya:yb, w-thickness:w], mask_alpha[ya:yb, w-thickness:w])
    details = {}
    for name, (src_band, out_band, alpha_band) in samples.items():
        opaque = alpha_band >= 250
        coverage = float(np.mean(opaque)) if opaque.size else 0.0
        if np.any(opaque):
            diff = np.abs(out_band.astype(np.int16) - src_band.astype(np.int16))
            max_diff = int(diff[opaque].max())
            changed = int(np.sum(np.any(diff[opaque] != 0, axis=1)))
        else:
            max_diff, changed = 999, -1
        details[name] = {"opaque_coverage": coverage, "max_channel_diff": max_diff, "changed_pixels": changed}
    passed = bool(details) and all(d["opaque_coverage"] >= 0.98 and d["max_channel_diff"] == 0 and d["changed_pixels"] == 0 for d in details.values())
    return {"pass": bool(passed), "sides": details}


def make_source_boundary_qa(source: Image.Image, manifest: dict, path: Path) -> None:
    """Create a source-side geometry inspection sheet for visual crop review."""
    l, t, r, b = [int(v) for v in manifest["crop"]]
    radius = int(manifest.get("corner_radius", 0))
    src = source.convert("RGB")
    overview = src.copy()
    od = ImageDraw.Draw(overview)
    if str(manifest.get("mode", "rounded-card")) in {"rounded-card", "dark-container"} and radius > 0:
        od.rounded_rectangle((l, t, r - 1, b - 1), radius=radius, outline=(220, 0, 0), width=1)
    else:
        od.rectangle((l, t, r - 1, b - 1), outline=(220, 0, 0), width=1)
    overview = label_panel(fit_thumbnail(overview, 900, 650), "Source with selected outer boundary")

    margin = 10
    cx1 = min(r, l + max(radius + 8, (r - l) // 8))
    cx2 = max(l, r - max(radius + 8, (r - l) // 8))
    cy1 = min(b, t + max(radius + 8, (b - t) // 8))
    cy2 = max(t, b - max(radius + 8, (b - t) // 8))

    panels = []
    # Top and bottom strips keep horizontal orientation.
    for label, y, boundary_row in (("Top boundary", t, margin), ("Bottom boundary", b, margin)):
        if cx2 <= cx1:
            continue
        if label.startswith("Top"):
            y1, y2 = max(0, y - margin), min(src.height, y + margin + 1)
            line_y = y - y1
        else:
            y1, y2 = max(0, y - margin - 1), min(src.height, y + margin)
            line_y = (y - 1) - y1
        strip = src.crop((cx1, y1, cx2, y2))
        scale_y = 8
        strip = strip.resize((min(900, strip.width), strip.height * scale_y), Image.Resampling.NEAREST)
        d = ImageDraw.Draw(strip)
        ly = int(round(line_y * scale_y))
        d.line((0, ly, strip.width - 1, ly), fill=(220, 0, 0), width=1)
        panels.append(label_panel(strip, label))

    # Left/right strips are rotated so the selected edge reads as a horizontal line.
    for label, x in (("Left boundary", l), ("Right boundary", r)):
        if cy2 <= cy1:
            continue
        if label.startswith("Left"):
            x1, x2 = max(0, x - margin), min(src.width, x + margin + 1)
            line_x = x - x1
        else:
            x1, x2 = max(0, x - margin - 1), min(src.width, x + margin)
            line_x = (x - 1) - x1
        strip = src.crop((x1, cy1, x2, cy2)).rotate(90, expand=True)
        # Rotation turns the boundary into a horizontal line; draw at the corresponding row.
        line_y = strip.height - 1 - line_x
        strip = strip.resize((min(900, strip.width), strip.height * 8), Image.Resampling.NEAREST)
        d = ImageDraw.Draw(strip)
        ly = int(round(line_y * 8))
        d.line((0, ly, strip.width - 1, ly), fill=(220, 0, 0), width=1)
        panels.append(label_panel(strip, label))

    cell_w = max([overview.width] + [p.width for p in panels])
    total_h = overview.height + sum(p.height for p in panels)
    sheet = Image.new("RGB", (cell_w, total_h), "white")
    y = 0
    sheet.paste(overview, (0, y)); y += overview.height
    for panel in panels:
        sheet.paste(panel, (0, y)); y += panel.height
    path.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(path, "PNG")


def make_edge_qa(result: Image.Image, mask: Image.Image, manifest: dict, path: Path) -> None:
    padding = int(manifest["padding"])
    ew, eh = [int(v) for v in manifest["element_size"]]

    # Flatten the UI interior to a neutral light fill while keeping the actual
    # alpha and shadow. This prevents legitimate text/icons near corners from
    # being mistaken for shadow contamination during visual QA.
    arr = np.asarray(result.convert("RGBA"), dtype=np.uint8).copy()
    element_canvas = np.zeros(arr.shape[:2], dtype=np.uint8)
    element_canvas[padding : padding + eh, padding : padding + ew] = np.asarray(mask, dtype=np.uint8)
    inside = element_canvas > 0
    arr[inside, 0:3] = 245
    inspection = Image.fromarray(arr, mode="RGBA")

    box_size = min(64, max(28, min(ew, eh) // 6))
    half = box_size // 2
    l, t = padding, padding
    r, b = padding + ew, padding + eh
    cx, cy = (l + r) // 2, (t + b) // 2
    centres = [
        ("Top-left", l, t),
        ("Top-right", r - 1, t),
        ("Bottom-left", l, b - 1),
        ("Bottom-right", r - 1, b - 1),
        ("Top edge", cx, t),
        ("Bottom edge", cx, b - 1),
        ("Left edge", l, cy),
        ("Right edge", r - 1, cy),
    ]

    panels = []
    for label, px, py in centres:
        x1, y1 = max(0, px - half), max(0, py - half)
        x2, y2 = min(inspection.width, px + half), min(inspection.height, py + half)
        crop_im = inspection.crop((x1, y1, x2, y2))
        bg = checkerboard(crop_im.size, tile=8)
        comp = composite_on(crop_im, bg)
        comp = comp.resize((comp.width * 4, comp.height * 4), Image.Resampling.NEAREST)
        panels.append(label_panel(comp, label))

    cell_w = max(p.width for p in panels)
    cell_h = max(p.height for p in panels)
    sheet = Image.new("RGB", (cell_w * 4, cell_h * 2), "white")
    for idx, panel in enumerate(panels):
        x = (idx % 4) * cell_w
        y = (idx // 4) * cell_h
        sheet.paste(panel, (x, y))
    path.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(path, "PNG")


def make_alpha_qa(result: Image.Image, path: Path) -> None:
    alpha = result.getchannel("A")
    # Black = transparent, white = opaque. Shadow should appear as a smooth
    # grey field with no text-shaped or localised discontinuities.
    path.parent.mkdir(parents=True, exist_ok=True)
    alpha.save(path, "PNG")


def verify_container(source, crop, mask, manifest) -> dict:
    """Check the chosen container independently of screenshot-edge detection."""
    l, t, r, b = crop
    radius = int(manifest.get("corner_radius", 0))
    content = manifest.get("content_bounds")
    if not content or len(content) != 4:
        return {"pass": False, "reason": "missing content bounds"}
    cl, ct, cr, cb = map(int, content)
    enclosed = l + 2 <= cl < cr <= r - 2 and t + 2 <= ct < cb <= b - 2
    valid_radius = 0 < radius < min(r-l, b-t) / 2
    a = np.asarray(mask, dtype=np.uint8)
    region = a[ct-t-2:cb-t+2, cl-l-2:cr-l+2] if enclosed else np.array([])
    opaque = bool(region.size and np.all(region == 255))
    # Rebuild the declared shape to reject a flood/text mask or altered mask.
    expected = Image.new("L", ((r-l)*8, (b-t)*8), 0)
    ImageDraw.Draw(expected).rounded_rectangle((0, 0, expected.width-1, expected.height-1), radius=radius*8, fill=255)
    expected = expected.resize((r-l, b-t), Image.Resampling.LANCZOS)
    shape_matches = mask.size == expected.size and np.array_equal(a, np.asarray(expected))
    margin = l > 0 and t > 0 and r < source.width and b < source.height
    return {"pass": bool(enclosed and opaque and valid_radius and shape_matches and margin),
            "content_and_background_opaque": opaque, "declared_shape_matches_mask": bool(shape_matches),
            "content_enclosed": enclosed, "valid_radius": valid_radius, "source_margin": margin}


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--source", required=True, type=Path)
    p.add_argument("--output", required=True, type=Path)
    p.add_argument("--manifest", required=True, type=Path)
    p.add_argument("--qa-dir", required=True, type=Path)
    args = p.parse_args()

    if not args.source.exists() or not args.output.exists() or not args.manifest.exists():
        p.error("source, output and manifest must all exist")

    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    mask_path = args.manifest.parent / manifest["mask_file"]
    if not mask_path.exists():
        raise RuntimeError(f"Mask file missing: {mask_path}")

    with Image.open(args.source) as im:
        source = im.convert("RGB")
    with Image.open(args.output) as im:
        output_info = dict(im.info)
        output_mode = im.mode
        result = im.convert("RGBA")
    with Image.open(mask_path) as im:
        mask = im.convert("L")

    tests: dict[str, dict] = {}
    source_hash = sha256_file(args.source)
    add_test(tests, "source_hash_matches_manifest", source_hash == manifest.get("source_sha256"), source_hash)
    add_test(tests, "output_tagged_as_generated", str(output_info.get(GENERATED_TAG, "")) == "1", output_info.get(GENERATED_TAG, ""))
    add_test(tests, "output_rgba", output_mode == "RGBA", output_mode)

    crop = [int(v) for v in manifest["crop"]]
    l, t, r, b = crop
    ew, eh = r - l, b - t
    padding = int(manifest["padding"])
    expected_size = (ew + 2 * padding, eh + 2 * padding)
    add_test(tests, "output_dimensions", result.size == expected_size, {"actual": list(result.size), "expected": list(expected_size)})
    add_test(tests, "mask_dimensions", mask.size == (ew, eh), {"actual": list(mask.size), "expected": [ew, eh]})
    add_test(tests, "crop_inside_source", l >= 0 and t >= 0 and r <= source.width and b <= source.height, crop)

    out = np.asarray(result, dtype=np.uint8)
    alpha = out[:, :, 3]
    add_test(tests, "has_true_transparency", bool(np.any(alpha == 0)), int(np.sum(alpha == 0)))
    edge_zero = bool(
        np.all(alpha[0, :] == 0)
        and np.all(alpha[-1, :] == 0)
        and np.all(alpha[:, 0] == 0)
        and np.all(alpha[:, -1] == 0)
    )
    add_test(tests, "outer_canvas_edges_transparent", edge_zero, "outermost canvas rows/columns")

    mask_a = np.asarray(mask, dtype=np.uint8)
    element_canvas = np.zeros(alpha.shape, dtype=np.uint8)
    if result.size == expected_size and mask.size == (ew, eh):
        element_canvas[padding : padding + eh, padding : padding + ew] = mask_a
    outside_element = element_canvas == 0

    shadow = manifest["shadow"]
    blur = int(shadow["radius"])
    ox = int(shadow["offset_x"])
    oy = int(shadow["offset_y"])
    opacity = int(shadow["opacity"])

    visible_outside = outside_element & (alpha > 0)
    if np.any(visible_outside):
        outside_rgb = out[:, :, :3][visible_outside]
        max_rgb = int(outside_rgb.max())
        pure_black = bool(np.all(outside_rgb == 0))
        max_outside_alpha = int(alpha[visible_outside].max())
    else:
        max_rgb = 0
        pure_black = True
        max_outside_alpha = 0
    add_test(tests, "shadow_region_contains_no_source_rgb", pure_black, {"max_rgb": max_rgb})
    add_test(tests, "outside_alpha_within_shadow_opacity", max_outside_alpha <= opacity, {"max_alpha": max_outside_alpha, "configured_opacity": opacity})

    zero_alpha_rgb_clean = bool(np.all(out[:, :, :3][alpha == 0] == 0)) if np.any(alpha == 0) else False
    add_test(tests, "transparent_pixels_have_zero_rgb", zero_alpha_rgb_clean, "RGB must be 0 wherever alpha is 0")

    guard = max(2, min(4, padding // 4))
    guard_clear = bool(
        np.all(alpha[:guard, :] == 0)
        and np.all(alpha[-guard:, :] == 0)
        and np.all(alpha[:, :guard] == 0)
        and np.all(alpha[:, -guard:] == 0)
    )
    add_test(tests, "transparent_guard_band", guard_clear, {"thickness": guard})

    shadow_metrics = shadow_distribution_metrics(alpha, padding, ew, eh, blur, ox, oy)
    add_test(tests, "shadow_visible_around_all_sides", shadow_metrics["pass"], shadow_metrics)

    # Interior fidelity: erode the opaque area to avoid the intentionally
    # reconstructed antialias band, then demand exact RGB identity.
    safe_mask = mask.point(lambda px: 255 if px == 255 else 0)
    if min(mask.size) >= 3:
        safe_mask = safe_mask.filter(ImageFilter.MinFilter(3))
    safe = np.asarray(safe_mask, dtype=np.uint8) == 255
    src_crop = np.asarray(source, dtype=np.uint8)[t:b, l:r, :]
    out_crop = out[padding : padding + eh, padding : padding + ew, :3]
    if src_crop.shape == out_crop.shape and np.any(safe):
        diff = np.abs(out_crop.astype(np.int16) - src_crop.astype(np.int16))
        max_diff = int(diff[safe].max())
        changed = int(np.sum(np.any(diff[safe] != 0, axis=1)))
        fidelity_pass = max_diff == 0 and changed == 0
    else:
        max_diff, changed, fidelity_pass = 999, -1, False
    add_test(tests, "safe_interior_exact_source_rgb", fidelity_pass, {"max_channel_diff": max_diff, "changed_pixels": changed})

    if str(manifest.get("mode", "rounded-card")) == "flood":
        edge_fidelity = {"pass": True, "not_applicable": "irregular flood mask"}
    else:
        edge_fidelity = straight_edge_preservation_metrics(src_crop, out_crop, mask_a, int(manifest.get("corner_radius", 0)), str(manifest.get("mode", "rounded-card")))
    add_test(tests, "straight_edge_source_fidelity", edge_fidelity["pass"], edge_fidelity)

    if str(manifest.get("mode", "rounded-card")) == "dark-container":
        geometry = verify_container(source, crop, mask, manifest)
    elif str(manifest.get("mode", "rounded-card")) == "flood":
        geometry = {"pass": True, "not_applicable": "irregular flood mask"}
    else:
        geometry = geometry_alignment_metrics(source, crop, int(manifest.get("corner_radius", 0)), str(manifest.get("mode", "rounded-card")))
    add_test(tests, "container_encloses_content" if manifest.get("mode") == "dark-container" else "geometry_follows_source_boundary", geometry["pass"], geometry)

    # Crop margin warning. Zero margin means missing pixels cannot be ruled out.
    margins = {"left": l, "top": t, "right": source.width - r, "bottom": source.height - b}
    not_clipped = all(v > 0 for v in margins.values())
    add_test(tests, "surface_not_flush_with_source_edge", not_clipped, margins)

    overall = all(item["pass"] for item in tests.values())
    failed_tests = [name for name, test in tests.items() if not test["pass"]]
    review_eligible = (failed_tests == ["geometry_follows_source_boundary"]
                      and manifest.get("release_status") == "needs-user-review"
                      and output_info.get("release_status") == "needs-user-review")
    report = {
        "pass": bool(overall),
        "automated_pass": bool(overall),
        "review_eligible": bool(review_eligible),
        "release_status": "needs-user-review" if review_eligible else ("automated-pass" if overall else "rejected"),
        "visual_review_required": True,
        "visual_checklist": [
            "Chosen dark container includes the entire button and label with background spacing; source-surface modes follow the existing outer boundary",
            "No visible border or rounded corner is clipped",
            "No source-page pixels or captured source shadow remain outside the UI",
            "Fresh shadow is visible and smoothly fading on top, bottom, left and right",
            "Checkerboard, white, black and grey views show genuine transparency with no halos",
            "Text, icons, spacing and scale are unchanged"
        ],
        "source": str(args.source),
        "output": str(args.output),
        "manifest": str(args.manifest),
        "tests": tests,
    }

    args.qa_dir.mkdir(parents=True, exist_ok=True)
    report_path = args.qa_dir / "verification.json"
    backgrounds_path = args.qa_dir / "qa_backgrounds.png"
    edges_path = args.qa_dir / "qa_edges.png"
    alpha_path = args.qa_dir / "qa_alpha.png"
    source_boundary_path = args.qa_dir / "qa_source_boundary.png"
    report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    make_background_qa(result, backgrounds_path)
    make_edge_qa(result, mask, manifest, edges_path)
    make_alpha_qa(result, alpha_path)
    make_source_boundary_qa(source, manifest, source_boundary_path)

    print(f"Verification: {'PASS' if overall else 'FAIL'}")
    print(f"Report:      {report_path}")
    print(f"Backgrounds: {backgrounds_path}")
    print(f"Edges:       {edges_path}")
    print(f"Alpha:       {alpha_path}")
    print(f"Source edge: {source_boundary_path}")
    if overall:
        print("Automated verification PASS only. Mandatory visual QA is still required before returning the PNG.")
    if review_eligible:
        print("Review candidate only: original shape/colour inspection and user judgement required. Automated pass remains false.")
    if not overall:
        for name, item in tests.items():
            if not item["pass"]:
                print(f"FAILED: {name}: {item['value']}")
        raise SystemExit(2)


if __name__ == "__main__":
    main()
