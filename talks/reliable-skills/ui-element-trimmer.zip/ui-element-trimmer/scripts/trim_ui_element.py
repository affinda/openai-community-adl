#!/usr/bin/env python3
"""Strictly isolate one UI element from a screenshot into a transparent PNG.

The pipeline is intentionally conservative:
1. analyse geometry from the untouched source;
2. render only the selected UI surface onto a blank RGBA canvas;
3. rebuild antialiased boundary pixels to remove old-background halos;
4. generate a fresh shadow from the mask only;
5. run objective self-checks and write a manifest for independent verification.

Requires Pillow and NumPy only.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from collections import deque
from pathlib import Path
from typing import Iterable

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, PngImagePlugin

VERSION = "5.2"
GENERATED_TAG = "ui_element_trimmer_generated"


def parse_crop(value: str) -> tuple[int, int, int, int]:
    try:
        parts = [int(x.strip()) for x in value.split(",")]
        if len(parts) != 4:
            raise ValueError
        x1, y1, x2, y2 = parts
        if x2 <= x1 or y2 <= y1:
            raise ValueError
        return x1, y1, x2, y2
    except Exception as exc:
        raise argparse.ArgumentTypeError(
            "--crop must be x1,y1,x2,y2 with x2>x1 and y2>y1"
        ) from exc


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def sidecar(output: Path, suffix: str) -> Path:
    return output.with_name(output.stem + suffix)


def ensure_original_source(path: Path, allow_derived: bool = False) -> None:
    with Image.open(path) as im:
        generated = str(im.info.get(GENERATED_TAG, "")).lower() in {"1", "true", "yes"}
    if generated and not allow_derived:
        raise RuntimeError(
            "Input is a previous UI Element Trimmer output. Restart from the untouched "
            "original screenshot. Use --allow-derived only for diagnostics, never for a normal retry."
        )


def rgb_array(image: Image.Image) -> np.ndarray:
    return np.asarray(image.convert("RGB"), dtype=np.uint8)


def transition_maps(rgb: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    f = rgb.astype(np.float32)
    dx = np.sqrt(np.sum((f[:, 1:, :] - f[:, :-1, :]) ** 2, axis=2))
    dy = np.sqrt(np.sum((f[1:, :, :] - f[:-1, :, :]) ** 2, axis=2))

    # Per-axis continuity scores. A true panel edge typically persists through a
    # large fraction of rows/columns; text and icons do not.
    vscore = np.mean(np.clip(dx / 32.0, 0.0, 1.0), axis=0)
    hscore = np.mean(np.clip(dy / 32.0, 0.0, 1.0), axis=1)

    h, w, _ = rgb.shape
    grad = np.zeros((h, w), dtype=np.float32)
    grad[:, 1:] = np.maximum(grad[:, 1:], dx)
    grad[:, :-1] = np.maximum(grad[:, :-1], dx)
    grad[1:, :] = np.maximum(grad[1:, :], dy)
    grad[:-1, :] = np.maximum(grad[:-1, :], dy)
    return vscore, hscore, grad


def local_maxima(scores: np.ndarray, limit: int = 18, min_sep: int = 2) -> list[int]:
    order = list(np.argsort(scores)[::-1])
    chosen: list[int] = []
    for idx in order:
        idx = int(idx)
        if float(scores[idx]) < 0.06:
            break
        if all(abs(idx - old) > min_sep for old in chosen):
            chosen.append(idx)
            if len(chosen) >= limit:
                break
    return chosen


def axis_pairs(scores: np.ndarray, axis_size: int, min_span_fraction: float = 0.18) -> list[tuple[float, int, int]]:
    points = local_maxima(scores)
    pairs: list[tuple[float, int, int]] = []
    min_span = max(20, int(axis_size * min_span_fraction))
    for i, a in enumerate(points):
        for b in points[i + 1 :]:
            lo, hi = sorted((a, b))
            span = hi - lo
            if span < min_span:
                continue
            strength = (float(scores[lo]) + float(scores[hi])) / 2.0
            span_fraction = span / max(1, axis_size - 1)
            # Favour strong paired transitions and, secondarily, the largest
            # coherent outer enclosure. This suppresses internal dividers.
            score = strength * (0.88 + 0.12 * span_fraction) + 0.16 * span_fraction
            pairs.append((score, lo, hi))
    pairs.sort(reverse=True)
    return pairs[:8]


def straight_edge_evidence(
    dx: np.ndarray,
    dy: np.ndarray,
    crop: tuple[int, int, int, int],
    threshold: float = 8.0,
) -> float:
    l, t, r, b = crop
    h = b - t
    w = r - l
    inset_y = max(3, int(h * 0.05))
    inset_x = max(3, int(w * 0.05))

    vals: list[float] = []
    if l - 1 >= 0:
        seg = dx[t + inset_y : b - inset_y, l - 1]
        if seg.size:
            vals.append(float(np.mean(seg >= threshold)))
    if r - 1 < dx.shape[1]:
        seg = dx[t + inset_y : b - inset_y, r - 1]
        if seg.size:
            vals.append(float(np.mean(seg >= threshold)))
    if t - 1 >= 0:
        seg = dy[t - 1, l + inset_x : r - inset_x]
        if seg.size:
            vals.append(float(np.mean(seg >= threshold)))
    if b - 1 < dy.shape[0]:
        seg = dy[b - 1, l + inset_x : r - inset_x]
        if seg.size:
            vals.append(float(np.mean(seg >= threshold)))
    return float(np.mean(vals)) if vals else 0.0


def sample_grad(grad: np.ndarray, x: float, y: float) -> float:
    xi = int(round(x))
    yi = int(round(y))
    if xi < 0 or yi < 0 or yi >= grad.shape[0] or xi >= grad.shape[1]:
        return 0.0
    return float(grad[yi, xi])


def radius_score(grad: np.ndarray, crop: tuple[int, int, int, int], radius: int) -> float:
    if radius <= 0:
        return 0.0
    l, t, r, b = crop
    if 2 * radius >= min(r - l, b - t):
        return 0.0

    # Sample only rounded-corner arcs. Exact-pixel sampling is intentional: a
    # wrong radius quickly leaves the true edge ridge, unlike a wide max filter.
    arcs = [
        (l + radius - 0.5, t + radius - 0.5, 180.0, 270.0),
        (r - radius - 0.5, t + radius - 0.5, 270.0, 360.0),
        (l + radius - 0.5, b - radius - 0.5, 90.0, 180.0),
        (r - radius - 0.5, b - radius - 0.5, 0.0, 90.0),
    ]
    values: list[float] = []
    for cx, cy, a0, a1 in arcs:
        for angle in np.linspace(a0, a1, 44):
            rad = math.radians(float(angle))
            x = cx + radius * math.cos(rad)
            y = cy + radius * math.sin(rad)
            values.append(sample_grad(grad, x, y))
    if not values:
        return 0.0
    arr = np.asarray(values, dtype=np.float32)
    return float(np.mean(np.log1p(arr)))


def fit_corner_radius(grad: np.ndarray, crop: tuple[int, int, int, int]) -> tuple[int, float]:
    l, t, r, b = crop
    limit = min(64, max(2, min(r - l, b - t) // 5))
    if limit < 4:
        return 0, 0.0
    scored = [(radius_score(grad, crop, rad), rad) for rad in range(3, limit + 1)]
    scored.sort(reverse=True)
    best_score, best_radius = scored[0]

    # Prefer the centre of a near-equal plateau rather than an arbitrary edge.
    close = [rad for score, rad in scored if score >= best_score * 0.992]
    if close:
        best_radius = int(round(float(np.median(close))))
        best_score = radius_score(grad, crop, best_radius)
    return best_radius, best_score


def analyse_geometry(rgb: np.ndarray, max_candidates: int = 6) -> dict:
    h, w, _ = rgb.shape
    f = rgb.astype(np.float32)
    dx = np.sqrt(np.sum((f[:, 1:, :] - f[:, :-1, :]) ** 2, axis=2))
    dy = np.sqrt(np.sum((f[1:, :, :] - f[:-1, :, :]) ** 2, axis=2))
    vscore, hscore, grad = transition_maps(rgb)
    xpairs = axis_pairs(vscore, w)
    ypairs = axis_pairs(hscore, h)
    candidates = []

    for xs, xa, xb in xpairs[:5]:
        for ys, ya, yb in ypairs[:5]:
            # Transition index is between pixels i and i+1. Surface is assumed
            # to lie inside the pair, so bounds start/end at i+1.
            crop = (xa + 1, ya + 1, xb + 1, yb + 1)
            l, t, r, b = crop
            if r <= l or b <= t:
                continue
            if (r - l) < max(20, int(w * 0.15)) or (b - t) < max(20, int(h * 0.15)):
                continue
            straight = straight_edge_evidence(dx, dy, crop)
            area = ((r - l) * (b - t)) / float(w * h)
            base = (xs + ys) / 2.0
            score = base + 0.45 * straight + 0.12 * area
            rad, rad_score = fit_corner_radius(grad, crop)
            candidates.append(
                {
                    "crop": [int(l), int(t), int(r), int(b)],
                    "corner_radius": int(rad),
                    "score": float(score),
                    "straight_edge_evidence": float(straight),
                    "radius_edge_score": float(rad_score),
                    "area_fraction": float(area),
                }
            )

    # Deduplicate near-identical crops.
    candidates.sort(key=lambda c: c["score"], reverse=True)
    deduped = []
    for c in candidates:
        crop = np.asarray(c["crop"], dtype=np.int32)
        if any(np.max(np.abs(crop - np.asarray(d["crop"], dtype=np.int32))) <= 2 for d in deduped):
            continue
        deduped.append(c)
        if len(deduped) >= max_candidates:
            break

    if not deduped:
        return {"candidates": [], "confidence": 0.0, "ambiguous": True}

    best = deduped[0]
    second = deduped[1] if len(deduped) > 1 else None
    straight = best["straight_edge_evidence"]
    score_gap = best["score"] - second["score"] if second else 0.25
    margin_score = max(0.0, min(1.0, score_gap / 0.12))
    confidence = max(0.0, min(1.0, 0.68 * straight + 0.32 * margin_score))

    materially_different_close_second = False
    if second:
        c1 = np.asarray(best["crop"])
        c2 = np.asarray(second["crop"])
        materially_different = int(np.max(np.abs(c1 - c2))) > 4
        materially_different_close_second = materially_different and score_gap < 0.035

    l, t, r, b = best["crop"]
    margins = {"left": l, "top": t, "right": w - r, "bottom": h - b}
    clipped_risk = any(v <= 0 for v in margins.values())
    low_margin_risk = any(v < 2 for v in margins.values())

    return {
        "candidates": deduped,
        "confidence": float(confidence),
        "ambiguous": bool(materially_different_close_second),
        "margins": margins,
        "clipped_risk": bool(clipped_risk),
        "low_margin_risk": bool(low_margin_risk),
    }


def draw_analysis_overlay(source: Image.Image, analysis: dict, path: Path) -> None:
    """Create a contact sheet with one candidate per panel.

    Showing candidates separately avoids overlapping outlines that make visual
    geometry review harder. Candidate 1 is always first.
    """
    candidates = analysis.get("candidates", [])[:4]
    if not candidates:
        source.convert("RGB").save(path, "PNG")
        return

    panels = []
    max_w, max_h = 560, 420
    for i, cand in enumerate(candidates, start=1):
        im = source.convert("RGBA").copy()
        draw = ImageDraw.Draw(im)
        l, t, r, b = [int(v) for v in cand["crop"]]
        radius = int(cand.get("corner_radius", 0))
        colour = (220, 0, 0, 255) if i == 1 else (0, 90, 210, 255)
        if radius > 0:
            draw.rounded_rectangle((l, t, r - 1, b - 1), radius=radius, outline=colour, width=2)
        else:
            draw.rectangle((l, t, r - 1, b - 1), outline=colour, width=2)

        scale = min(1.0, max_w / im.width, max_h / im.height)
        if scale < 1.0:
            im = im.resize((int(round(im.width * scale)), int(round(im.height * scale))), Image.Resampling.LANCZOS)
        bar = 34
        panel = Image.new("RGB", (im.width, im.height + bar), "white")
        panel.paste(im.convert("RGB"), (0, bar))
        pd = ImageDraw.Draw(panel)
        pd.text(
            (6, 6),
            f"Candidate {i}: crop={l},{t},{r},{b}  radius={radius}  score={cand['score']:.3f}",
            fill="black",
        )
        panels.append(panel)

    cell_w = max(panel.width for panel in panels)
    cell_h = max(panel.height for panel in panels)
    cols = 2 if len(panels) > 1 else 1
    rows = (len(panels) + cols - 1) // cols
    sheet = Image.new("RGB", (cell_w * cols, cell_h * rows), "white")
    for idx, panel in enumerate(panels):
        sheet.paste(panel, ((idx % cols) * cell_w, (idx // cols) * cell_h))
    path.parent.mkdir(parents=True, exist_ok=True)
    sheet.save(path, "PNG")


def geometry_alignment_metrics(
    source_rgb: np.ndarray,
    crop: tuple[int, int, int, int],
    radius: int,
    mode: str,
) -> dict:
    """Measure whether the requested boundary is the *outer* source boundary.

    A strong gradient alone is not enough: an inward crop can also land on a
    strong border/content transition. For each straight side, compare the
    selected boundary against nearby +/-3 px alternatives and require the
    selected location to sit on the local transition peak. Also require the
    cross-boundary transition to dominate the immediately inner/outer steps.
    """
    f = source_rgb.astype(np.float32)
    dx = np.sqrt(np.sum((f[:, 1:, :] - f[:, :-1, :]) ** 2, axis=2))
    dy = np.sqrt(np.sum((f[1:, :, :] - f[:-1, :, :]) ** 2, axis=2))
    h, w, _ = source_rgb.shape
    grad = np.zeros((h, w), dtype=np.float32)
    grad[:, 1:] = np.maximum(grad[:, 1:], dx)
    grad[:, :-1] = np.maximum(grad[:, :-1], dx)
    grad[1:, :] = np.maximum(grad[1:, :], dy)
    grad[:-1, :] = np.maximum(grad[:-1, :], dy)

    l, t, r, b = crop
    edge_exclude_y = max(4, int((b - t) * 0.05), int(radius) + 2 if radius else 4)
    edge_exclude_x = max(4, int((r - l) * 0.05), int(radius) + 2 if radius else 4)
    ys = slice(min(b, t + edge_exclude_y), max(t, b - edge_exclude_y))
    xs = slice(min(r, l + edge_exclude_x), max(l, r - edge_exclude_x))

    def _score(arr: np.ndarray) -> float:
        return float(np.mean(np.log1p(arr))) if arr.size else 0.0

    def _dominance(cross: np.ndarray, inner: np.ndarray | None, outer: np.ndarray | None) -> float:
        if not cross.size:
            return 0.0
        baseline = np.zeros_like(cross)
        if inner is not None and inner.shape == cross.shape:
            baseline = np.maximum(baseline, inner)
        if outer is not None and outer.shape == cross.shape:
            baseline = np.maximum(baseline, outer)
        # A real outer edge should be materially stronger than adjacent steps.
        good = (cross >= 6.0) & (cross >= baseline * 1.25 + 1.5)
        return float(np.mean(good))

    side_details: dict[str, dict] = {}

    def _vertical_side(name: str, boundary_x: int, is_left: bool) -> None:
        candidates: dict[int, float] = {}
        for off in range(-3, 4):
            x = boundary_x + off
            if 1 <= x < w:
                arr = dx[ys, x - 1]
                candidates[off] = _score(arr)
        chosen = candidates.get(0, 0.0)
        best_off = max(candidates, key=candidates.get) if candidates else 99
        best = candidates.get(best_off, 0.0)
        ratio = chosen / max(best, 1e-6)
        x = boundary_x
        if 1 <= x < w:
            cross = dx[ys, x - 1]
            if is_left:
                inner = dx[ys, x] if x < w - 1 else None
                outer = dx[ys, x - 2] if x >= 2 else None
            else:
                inner = dx[ys, x - 2] if x >= 2 else None
                outer = dx[ys, x] if x < w - 1 else None
            dom = _dominance(cross, inner, outer)
        else:
            dom = 0.0
        side_details[name] = {
            "selected_log_strength": chosen,
            "best_nearby_offset": int(best_off),
            "selected_to_best_ratio": float(ratio),
            "cross_step_dominance": float(dom),
        }

    def _horizontal_side(name: str, boundary_y: int, is_top: bool) -> None:
        candidates: dict[int, float] = {}
        for off in range(-3, 4):
            y = boundary_y + off
            if 1 <= y < h:
                arr = dy[y - 1, xs]
                candidates[off] = _score(arr)
        chosen = candidates.get(0, 0.0)
        best_off = max(candidates, key=candidates.get) if candidates else 99
        best = candidates.get(best_off, 0.0)
        ratio = chosen / max(best, 1e-6)
        y = boundary_y
        if 1 <= y < h:
            cross = dy[y - 1, xs]
            if is_top:
                inner = dy[y, xs] if y < h - 1 else None
                outer = dy[y - 2, xs] if y >= 2 else None
            else:
                inner = dy[y - 2, xs] if y >= 2 else None
                outer = dy[y, xs] if y < h - 1 else None
            dom = _dominance(cross, inner, outer)
        else:
            dom = 0.0
        side_details[name] = {
            "selected_log_strength": chosen,
            "best_nearby_offset": int(best_off),
            "selected_to_best_ratio": float(ratio),
            "cross_step_dominance": float(dom),
        }

    _vertical_side("left", l, True)
    _vertical_side("right", r, False)
    _horizontal_side("top", t, True)
    _horizontal_side("bottom", b, False)

    # Legacy aggregate measures remain useful as a broad signal.
    straight_values: list[float] = []
    ih = max(3, int((b - t) * 0.05))
    iw = max(3, int((r - l) * 0.05))
    if 0 <= l < w:
        straight_values.extend(grad[t + ih : b - ih, l].tolist())
    if 0 <= r - 1 < w:
        straight_values.extend(grad[t + ih : b - ih, r - 1].tolist())
    if 0 <= t < h:
        straight_values.extend(grad[t, l + iw : r - iw].tolist())
    if 0 <= b - 1 < h:
        straight_values.extend(grad[b - 1, l + iw : r - iw].tolist())
    straight_arr = np.asarray(straight_values, dtype=np.float32)
    straight_log = float(np.mean(np.log1p(straight_arr))) if straight_arr.size else 0.0
    straight_fraction = float(np.mean(straight_arr >= 5.0)) if straight_arr.size else 0.0

    corner_log = 0.0
    corner_ratio = 1.0
    if mode == "rounded-card" and radius > 0:
        corner_log = float(radius_score(grad, crop, radius))
        corner_ratio = corner_log / max(straight_log, 1e-6)

    side_pass = all(
        abs(int(d["best_nearby_offset"])) <= 1
        and float(d["selected_to_best_ratio"]) >= 0.90
        and float(d["cross_step_dominance"]) >= 0.55
        for d in side_details.values()
    )
    passed = straight_fraction >= 0.70 and straight_log >= 2.0 and side_pass
    if mode == "rounded-card" and radius > 0:
        passed = passed and corner_ratio >= 0.78

    return {
        "pass": bool(passed),
        "straight_edge_fraction": straight_fraction,
        "straight_log_strength": straight_log,
        "corner_log_strength": corner_log,
        "corner_to_straight_ratio": corner_ratio,
        "sides": side_details,
    }

def rounded_mask(size: tuple[int, int], radius: int, supersample: int = 8) -> Image.Image:
    w, h = size
    radius = max(0, min(int(radius), min(w, h) // 2))
    if radius <= 0:
        return Image.new("L", size, 255)
    ss = max(4, int(supersample))
    hi = Image.new("L", (w * ss, h * ss), 0)
    draw = ImageDraw.Draw(hi)
    draw.rounded_rectangle(
        (0, 0, w * ss - 1, h * ss - 1), radius=radius * ss, fill=255
    )
    return hi.resize((w, h), Image.Resampling.LANCZOS)


def decontaminate_antialiased_edge(rgb: np.ndarray, alpha: np.ndarray) -> np.ndarray:
    """Replace only partially covered edge RGB with nearest opaque interior RGB.

    Screenshot edge pixels are already composited against the old background.
    Reusing those RGB values with a new alpha causes dark/light halos. Fully
    opaque interior pixels remain bit-identical to the source.
    """
    out = rgb.copy()
    opaque = alpha >= 250
    partial = (alpha > 0) & (alpha < 250)
    ys, xs = np.where(partial)
    h, w = alpha.shape

    for y, x in zip(ys.tolist(), xs.tolist()):
        found = None
        for rad in range(1, 7):
            y1, y2 = max(0, y - rad), min(h, y + rad + 1)
            x1, x2 = max(0, x - rad), min(w, x + rad + 1)
            oy, ox = np.where(opaque[y1:y2, x1:x2])
            if len(ox):
                gy = oy + y1
                gx = ox + x1
                dist2 = (gy - y) ** 2 + (gx - x) ** 2
                best = int(np.argmin(dist2))
                found = (int(gy[best]), int(gx[best]))
                break
        if found is not None:
            out[y, x] = rgb[found[0], found[1]]
    out[alpha == 0] = 0
    return out


def flood_foreground_mask(image: Image.Image, threshold: float, edge_sample: int = 6) -> Image.Image:
    rgba = np.asarray(image.convert("RGBA"), dtype=np.uint8)
    rgb = rgba[:, :, :3].astype(np.float32)
    h, w, _ = rgb.shape
    e = max(1, min(edge_sample, h // 4, w // 4))
    samples = np.concatenate(
        [
            rgb[:e].reshape(-1, 3),
            rgb[-e:].reshape(-1, 3),
            rgb[:, :e].reshape(-1, 3),
            rgb[:, -e:].reshape(-1, 3),
        ],
        axis=0,
    )
    bg = np.median(samples, axis=0)
    dist = np.sqrt(np.sum((rgb - bg[None, None, :]) ** 2, axis=2))
    candidate = (dist <= threshold) | (rgba[:, :, 3] == 0)

    outside = np.zeros((h, w), dtype=bool)
    q: deque[tuple[int, int]] = deque()

    def seed(y: int, x: int) -> None:
        if candidate[y, x] and not outside[y, x]:
            outside[y, x] = True
            q.append((y, x))

    for x in range(w):
        seed(0, x)
        seed(h - 1, x)
    for y in range(h):
        seed(y, 0)
        seed(y, w - 1)

    while q:
        y, x = q.popleft()
        for ny, nx in ((y - 1, x), (y + 1, x), (y, x - 1), (y, x + 1)):
            if 0 <= ny < h and 0 <= nx < w and candidate[ny, nx] and not outside[ny, nx]:
                outside[ny, nx] = True
                q.append((ny, nx))

    fg = ~outside
    ys, xs = np.where(fg)
    if not len(xs):
        raise RuntimeError("Flood mode could not isolate a foreground element")
    return Image.fromarray((fg.astype(np.uint8) * 255), mode="L")


def crop_mask_and_image(
    source: Image.Image,
    mode: str,
    crop: tuple[int, int, int, int],
    radius: int,
    threshold: float,
) -> tuple[Image.Image, Image.Image, tuple[int, int, int, int]]:
    element = source.convert("RGBA").crop(crop)
    adjusted_crop = crop
    if mode == "rectangle":
        mask = Image.new("L", element.size, 255)
    elif mode == "flood":
        mask = flood_foreground_mask(element, threshold)
        bbox = mask.getbbox()
        if bbox is None:
            raise RuntimeError("Flood mode produced an empty foreground mask")
        bx1, by1, bx2, by2 = bbox
        element = element.crop(bbox)
        mask = mask.crop(bbox)
        l, t, _, _ = crop
        adjusted_crop = (l + bx1, t + by1, l + bx2, t + by2)
    else:
        mask = rounded_mask(element.size, radius)

    rgb = np.asarray(element.convert("RGB"), dtype=np.uint8)
    alpha = np.asarray(mask, dtype=np.uint8)
    cleaned_rgb = decontaminate_antialiased_edge(rgb, alpha)
    cleaned = Image.fromarray(cleaned_rgb, mode="RGB").convert("RGBA")
    cleaned.putalpha(mask)
    return cleaned, mask, adjusted_crop


def shadow_padding(blur: int, offset_x: int, offset_y: int) -> int:
    # Pillow GaussianBlur has finite practical support. 4x radius plus offsets
    # leaves a clean zero-alpha guard band even for small images.
    return max(6, int(math.ceil(blur * 4 + max(abs(offset_x), abs(offset_y)) + 2)))


def render_with_shadow(
    element: Image.Image,
    mask: Image.Image,
    blur: int,
    offset_x: int,
    offset_y: int,
    opacity: int,
) -> tuple[Image.Image, int, Image.Image]:
    """Render a fresh shadow on an expanded canvas, then place the UI above it.

    Critical invariant: blur the mask *after* it has been placed on the padded
    canvas. Blurring an element-sized mask clips the Gaussian field at the
    element bounds and produces the exact failure this skill is designed to
    prevent: no shadow on the top/left/right edges.
    """
    opacity = max(0, min(255, int(opacity)))
    blur = max(0, int(blur))
    padding = shadow_padding(blur, offset_x, offset_y)
    w, h = element.size
    canvas_size = (w + 2 * padding, h + 2 * padding)

    shadow_seed = Image.new("L", canvas_size, 0)
    shadow_seed.paste(mask, (padding + offset_x, padding + offset_y))
    shadow_alpha = shadow_seed.filter(ImageFilter.GaussianBlur(blur))
    if opacity < 255:
        shadow_alpha = shadow_alpha.point(lambda p: int(round(p * opacity / 255.0)))

    shadow = Image.new("RGBA", canvas_size, (0, 0, 0, 255))
    shadow.putalpha(shadow_alpha)
    out = Image.new("RGBA", canvas_size, (0, 0, 0, 0))
    out.alpha_composite(shadow)
    out.alpha_composite(element, (padding, padding))

    arr = np.asarray(out, dtype=np.uint8).copy()
    arr[arr[:, :, 3] == 0, :3] = 0
    out = Image.fromarray(arr, mode="RGBA")
    return out, padding, shadow_alpha


def shadow_distribution_metrics(
    alpha: np.ndarray,
    padding: int,
    element_size: tuple[int, int],
    blur: int,
    offset_x: int,
    offset_y: int,
) -> dict:
    """Check that a soft generated shadow exists, fades, and clears every side.

    This deliberately inspects the rendered alpha rather than recreating the
    Gaussian operation. It therefore catches clipped or one-sided shadows even
    if the rendering algorithm itself is wrong.
    """
    h_canvas, w_canvas = alpha.shape
    ew, eh = element_size
    l, t, r, b = padding, padding, padding + ew, padding + eh
    xpad = max(4, min(ew // 8, max(4, ew // 3)))
    ypad = max(4, min(eh // 8, max(4, eh // 3)))
    x1, x2 = min(r, l + xpad), max(l, r - xpad)
    y1, y2 = min(b, t + ypad), max(t, b - ypad)
    max_depth = max(3, min(padding - 1, blur * 4 + max(abs(offset_x), abs(offset_y)) + 2))

    def row_profile(start: int, step: int) -> list[float]:
        vals: list[float] = []
        for d in range(max_depth):
            y = start + step * d
            if not (0 <= y < h_canvas) or x2 <= x1:
                break
            vals.append(float(np.mean(alpha[y, x1:x2])))
        return vals

    def col_profile(start: int, step: int) -> list[float]:
        vals: list[float] = []
        for d in range(max_depth):
            x = start + step * d
            if not (0 <= x < w_canvas) or y2 <= y1:
                break
            vals.append(float(np.mean(alpha[y1:y2, x])))
        return vals

    profiles = {
        "top": row_profile(t - 1, -1),
        "bottom": row_profile(b, 1),
        "left": col_profile(l - 1, -1),
        "right": col_profile(r, 1),
    }

    def extent(values: list[float]) -> int:
        reach = 0
        for i, value in enumerate(values, start=1):
            if value > 0.0:
                reach = i
        return reach

    def fade_ok(values: list[float]) -> tuple[bool, float]:
        positive = [v for v in values if v > 0.0]
        if blur <= 0:
            return True, 0.0
        if len(positive) < 2:
            return False, positive[-1] if positive else 0.0
        tail = positive[-1]
        # A clean Gaussian should decay to a nearly invisible quantised tail.
        # Permit local plateaus from 8-bit rounding but reject a hard cut.
        far = values[min(len(values) - 1, max(1, len(values) // 2))]
        ok = tail <= 2.5 and far <= max(values[0] * 0.65, 4.0)
        return bool(ok), float(tail)

    extents = {name: extent(values) for name, values in profiles.items()}
    near_means = {name: (values[0] if values else 0.0) for name, values in profiles.items()}
    fade_details = {name: fade_ok(values) for name, values in profiles.items()}
    min_extent = max(2, blur // 2) if blur > 0 else 0
    present = all(v >= min_extent for v in extents.values()) and all(v >= 0.5 for v in near_means.values())

    horizontal_extent_balance = True
    horizontal_alpha_balance = True
    if offset_x == 0 and blur > 0:
        horizontal_extent_balance = abs(extents["left"] - extents["right"]) <= 2
        left_a, right_a = near_means["left"], near_means["right"]
        ratio = min(left_a, right_a) / max(left_a, right_a, 1e-6)
        horizontal_alpha_balance = ratio >= 0.80

    fade_pass = all(ok for ok, _tail in fade_details.values())
    return {
        "pass": bool(present and horizontal_extent_balance and horizontal_alpha_balance and fade_pass),
        "extents": extents,
        "near_edge_mean_alpha": near_means,
        "tail_mean_alpha": {name: tail for name, (_ok, tail) in fade_details.items()},
        "minimum_required_extent": int(min_extent),
        "horizontal_extent_balance": bool(horizontal_extent_balance),
        "horizontal_alpha_balance": bool(horizontal_alpha_balance),
        "fade_pass": bool(fade_pass),
    }

def straight_edge_preservation_metrics(
    source_crop: np.ndarray,
    output_crop: np.ndarray,
    mask_alpha: np.ndarray,
    radius: int,
    mode: str,
) -> dict:
    """Verify that the selected outer border itself survives the mask.

    Interior fidelity tests intentionally erode the edge. This companion test
    checks the first two pixel rows/columns of the straight sides, excluding
    rounded corners, so a visible one-pixel border cannot silently disappear.
    """
    h, w, _ = source_crop.shape
    if h < 3 or w < 3:
        return {"pass": False, "reason": "element too small for edge-fidelity check"}
    exclude = max(3, int(radius) + 2 if mode in {"rounded-card", "dark-container"} and radius > 0 else 3)
    xa, xb = min(w, exclude), max(0, w - exclude)
    ya, yb = min(h, exclude), max(0, h - exclude)
    thickness = min(2, h, w)

    samples: dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]] = {}
    if xb > xa:
        samples["top"] = (source_crop[:thickness, xa:xb], output_crop[:thickness, xa:xb], mask_alpha[:thickness, xa:xb])
        samples["bottom"] = (source_crop[h-thickness:h, xa:xb], output_crop[h-thickness:h, xa:xb], mask_alpha[h-thickness:h, xa:xb])
    if yb > ya:
        samples["left"] = (source_crop[ya:yb, :thickness], output_crop[ya:yb, :thickness], mask_alpha[ya:yb, :thickness])
        samples["right"] = (source_crop[ya:yb, w-thickness:w], output_crop[ya:yb, w-thickness:w], mask_alpha[ya:yb, w-thickness:w])

    details: dict[str, dict] = {}
    for name, (src_band, out_band, alpha_band) in samples.items():
        opaque = alpha_band >= 250
        coverage = float(np.mean(opaque)) if opaque.size else 0.0
        if np.any(opaque):
            diff = np.abs(out_band.astype(np.int16) - src_band.astype(np.int16))
            max_diff = int(diff[opaque].max())
            changed = int(np.sum(np.any(diff[opaque] != 0, axis=1)))
        else:
            max_diff, changed = 999, -1
        details[name] = {
            "opaque_coverage": coverage,
            "max_channel_diff": max_diff,
            "changed_pixels": changed,
        }

    passed = bool(details) and all(
        d["opaque_coverage"] >= 0.98 and d["max_channel_diff"] == 0 and d["changed_pixels"] == 0
        for d in details.values()
    )
    return {"pass": passed, "sides": details}


def eroded_opaque_mask(mask: Image.Image, size: int = 3) -> np.ndarray:
    binary = mask.point(lambda p: 255 if p == 255 else 0)
    if min(mask.size) >= size:
        binary = binary.filter(ImageFilter.MinFilter(size=size))
    return np.asarray(binary, dtype=np.uint8) == 255


def boundary_colour_evidence(rgb, crop, radius) -> dict:
    """Report source-only colour samples; these inform review, not an automatic pass."""
    l, t, r, b = crop
    ex = max(radius + 4, 6)
    xa, xb = l + ex, r - ex
    ya, yb = t + ex, b - ex
    h, w = rgb.shape[:2]
    samples = {
        "top": (rgb[max(0,t-8):t, xa:xb], rgb[t+4:min(b,t+12), xa:xb]),
        "bottom": (rgb[b:min(h,b+8), xa:xb], rgb[max(t,b-12):b-4, xa:xb]),
        "left": (rgb[ya:yb, max(0,l-8):l], rgb[ya:yb, l+4:min(r,l+12)]),
        "right": (rgb[ya:yb, r:min(w,r+8)], rgb[ya:yb, max(l,r-12):r-4]),
    }
    evidence = {}
    for side, (outside, inside) in samples.items():
        if not outside.size or not inside.size:
            evidence[side] = {"available": False}
            continue
        bg = np.median(outside.reshape(-1,3),axis=0)
        fg = np.median(inside.reshape(-1,3),axis=0)
        evidence[side] = {"outside_median_rgb": bg.tolist(), "inside_median_rgb": fg.tolist(),
                          "colour_distance": float(np.linalg.norm(fg-bg))}
    return {"source_only": True, "sides": evidence,
            "note": "Inspect original outline, rounded corners and colour transition. Sampling does not prove an exact boundary."}


def container_geometry_metrics(source, crop, mask, content_bounds) -> dict:
    """A chosen container must preserve its content plus two pixels of background."""
    l, t, r, b = crop
    source_margin = l > 0 and t > 0 and r < source.width and b < source.height
    if content_bounds is None:
        return {"pass": False, "reason": "missing content bounds"}
    cl, ct, cr, cb = content_bounds
    enclosed = l <= cl - 2 < cr + 2 <= r and t <= ct - 2 < cb + 2 <= b
    a = np.asarray(mask, dtype=np.uint8)
    protected = a[ct - t - 2:cb - t + 2, cl - l - 2:cr - l + 2] if enclosed else np.array([])
    opaque = bool(protected.size and np.all(protected == 255))
    return {"pass": bool(source_margin and enclosed and opaque),
            "source_margin": source_margin, "content_with_background_enclosed": enclosed,
            "content_and_two_pixel_margin_opaque": opaque,
            "visual_review_required": "Confirm these bounds include every intended label/icon and no unrelated UI"}


def internal_verify(
    source: Image.Image,
    result: Image.Image,
    crop: tuple[int, int, int, int],
    mask: Image.Image,
    padding: int,
    shadow_alpha: Image.Image,
    shadow_offset: tuple[int, int],
    shadow_blur: int,
    mode: str,
    radius: int,
    content_bounds: tuple[int, int, int, int] | None = None,
) -> dict:
    src = np.asarray(source.convert("RGB"), dtype=np.uint8)
    out = np.asarray(result.convert("RGBA"), dtype=np.uint8)
    l, t, r, b = crop
    w, h = r - l, b - t
    expected_size = (w + 2 * padding, h + 2 * padding)

    tests: dict[str, dict] = {}

    def add(name: str, passed: bool, value) -> None:
        tests[name] = {"pass": bool(passed), "value": value}

    add("rgba_mode", result.mode == "RGBA", result.mode)
    add("expected_dimensions", result.size == expected_size, list(result.size))
    alpha = out[:, :, 3]
    add("has_fully_transparent_pixels", bool(np.any(alpha == 0)), int(np.sum(alpha == 0)))
    add("canvas_edges_fully_transparent", bool(
        np.all(alpha[0, :] == 0)
        and np.all(alpha[-1, :] == 0)
        and np.all(alpha[:, 0] == 0)
        and np.all(alpha[:, -1] == 0)
    ), "outermost rows and columns")

    mask_a = np.asarray(mask, dtype=np.uint8)
    element_canvas = np.zeros(alpha.shape, dtype=np.uint8)
    element_canvas[padding : padding + h, padding : padding + w] = mask_a
    outside_element = element_canvas == 0
    visible_outside = outside_element & (alpha > 0)
    if np.any(visible_outside):
        shadow_rgb = out[:, :, :3][visible_outside]
        pure_shadow = bool(np.all(shadow_rgb == 0))
        max_shadow_rgb = int(shadow_rgb.max())
    else:
        pure_shadow = True
        max_shadow_rgb = 0
    add("outside_pixels_are_pure_generated_shadow", pure_shadow, max_shadow_rgb)

    # The renderer now returns a full-canvas shadow alpha field. This permits an
    # exact internal consistency check while the independent verifier below uses
    # different geometric tests to avoid circular verification.
    sh = np.asarray(shadow_alpha, dtype=np.uint8)
    add("shadow_alpha_matches_canvas", sh.shape == alpha.shape, {"shadow": list(sh.shape), "canvas": list(alpha.shape)})
    allowed = (sh > 0) | (element_canvas > 0) if sh.shape == alpha.shape else (element_canvas > 0)
    contamination = (alpha > 0) & ~allowed
    add("no_alpha_outside_ui_or_shadow", not bool(np.any(contamination)), int(np.sum(contamination)))

    guard = max(2, min(4, padding // 4))
    guard_clear = bool(
        np.all(alpha[:guard, :] == 0)
        and np.all(alpha[-guard:, :] == 0)
        and np.all(alpha[:, :guard] == 0)
        and np.all(alpha[:, -guard:] == 0)
    )
    add("transparent_guard_band", guard_clear, {"thickness": guard})

    ox, oy = shadow_offset
    shadow_metrics = shadow_distribution_metrics(alpha, padding, (w, h), shadow_blur, ox, oy)
    add("shadow_visible_around_all_sides", shadow_metrics["pass"], shadow_metrics)

    # Safe opaque interior must match source RGB exactly. This intentionally
    # excludes the narrow reconstructed antialias band.
    safe = eroded_opaque_mask(mask, 3)
    source_crop = src[t:b, l:r, :]
    out_element = out[padding : padding + h, padding : padding + w, :3]
    diffs = np.abs(out_element.astype(np.int16) - source_crop.astype(np.int16))
    if np.any(safe):
        max_diff = int(diffs[safe].max())
        changed = int(np.sum(np.any(diffs[safe] != 0, axis=1)))
    else:
        max_diff = 0
        changed = 0
    add("safe_interior_source_fidelity", max_diff == 0 and changed == 0, {"max_channel_diff": max_diff, "changed_pixels": changed})

    if mode == "flood":
        edge_fidelity = {"pass": True, "not_applicable": "irregular flood mask"}
    else:
        edge_fidelity = straight_edge_preservation_metrics(source_crop, out_element, mask_a, radius, mode)
    add("straight_edge_source_fidelity", edge_fidelity["pass"], edge_fidelity)

    if mode == "dark-container":
        geometry = container_geometry_metrics(source, crop, mask, content_bounds)
    elif mode == "flood":
        geometry = {"pass": True, "not_applicable": "irregular flood mask"}
    else:
        geometry = geometry_alignment_metrics(src, crop, radius, mode)
    add("container_encloses_content" if mode == "dark-container" else "geometry_follows_source_boundary", geometry["pass"], geometry)

    overall = all(item["pass"] for item in tests.values())
    return {"pass": bool(overall), "tests": tests}


def save_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--mode", choices=("auto", "rounded-card", "rectangle", "flood", "dark-container"), default="auto")
    parser.add_argument("--crop", type=parse_crop, default=None)
    parser.add_argument("--corner-radius", type=int, default=None)
    parser.add_argument("--content-bounds", type=parse_crop, default=None, help="Source bounds of all button/icon/label pixels; required for dark-container")
    parser.add_argument("--threshold", type=float, default=18.0)
    parser.add_argument("--analyse-only", action="store_true")
    parser.add_argument("--review-boundary", action="store_true", help="Save a user-review candidate when ONLY source-boundary geometry is uncertain; never marks it passed")
    parser.add_argument("--allow-derived", action="store_true")
    parser.add_argument("--shadow-radius", type=int, default=6)
    parser.add_argument("--shadow-x", type=int, default=0)
    parser.add_argument("--shadow-y", type=int, default=3)
    parser.add_argument("--shadow-opacity", type=int, default=42)
    parser.add_argument("--min-auto-confidence", type=float, default=0.58)
    args = parser.parse_args()

    if not args.input.exists():
        parser.error(f"Input file does not exist: {args.input}")
    ensure_original_source(args.input, args.allow_derived)
    source_hash = sha256_file(args.input)

    with Image.open(args.input) as opened:
        source = opened.convert("RGBA")
    rgb = rgb_array(source)
    analysis = analyse_geometry(rgb)
    analysis.update(
        {
            "version": VERSION,
            "source_sha256": source_hash,
            "source_size": list(source.size),
        }
    )
    analysis_json = sidecar(args.output, ".analysis.json")
    analysis_png = sidecar(args.output, ".analysis.png")
    save_json(analysis_json, analysis)
    draw_analysis_overlay(source, analysis, analysis_png)

    if args.analyse_only:
        print(f"Analysis: {analysis_json}")
        print(f"Overlay:  {analysis_png}")
        if analysis.get("candidates"):
            c = analysis["candidates"][0]
            print(f"Candidate 1 crop={','.join(map(str, c['crop']))} radius={c['corner_radius']} confidence={analysis['confidence']:.3f}")
        else:
            print("No confident rectangular candidate found.")
        return

    explicit = args.crop is not None
    if args.review_boundary and (not explicit or args.corner_radius is None or args.mode not in {"rounded-card", "rectangle"}):
        raise RuntimeError("--review-boundary requires an inspected explicit crop and radius in rounded-card or rectangle mode")
    if args.review_boundary and not (0 < args.crop[0] < args.crop[2] < source.width and 0 < args.crop[1] < args.crop[3] < source.height):
        raise RuntimeError("Boundary review cannot accept a crop flush with or outside the original source")
    if args.mode == "dark-container":
        if not explicit or args.content_bounds is None or args.corner_radius is None:
            raise RuntimeError("dark-container requires --crop, --content-bounds and --corner-radius after source inspection")
        if not 0 < args.corner_radius < min(args.crop[2] - args.crop[0], args.crop[3] - args.crop[1]) / 2:
            raise RuntimeError("dark-container requires a positive radius smaller than half its shortest side")
    elif args.content_bounds is not None:
        raise RuntimeError("--content-bounds is only valid with dark-container")
    if args.mode == "flood" and not explicit:
        raise RuntimeError(
            "Flood mode requires an explicit --crop around the irregular target with some surrounding background. "
            "This prevents accidental isolation of unrelated page regions."
        )
    if explicit:
        crop = args.crop
        geometry_confidence = 1.0
    else:
        if not analysis.get("candidates"):
            raise RuntimeError(
                "No geometric candidate found. Inspect the analysis overlay and provide --crop, "
                "or use flood mode only for a clearly contrasting irregular element."
            )
        if analysis.get("clipped_risk"):
            raise RuntimeError("Automatic geometry touches the screenshot edge; the UI may be clipped. Use the untouched source with visible margin or provide an explicit crop after inspection.")
        if analysis.get("ambiguous") or float(analysis.get("confidence", 0.0)) < args.min_auto_confidence:
            raise RuntimeError(
                "Automatic geometry is not confident enough to render safely. Inspect the analysis overlay and rerun with explicit --crop and --corner-radius."
            )
        crop = tuple(int(v) for v in analysis["candidates"][0]["crop"])
        geometry_confidence = float(analysis["confidence"])

    l, t, r, b = crop
    if l < 0 or t < 0 or r > source.width or b > source.height:
        raise RuntimeError("Crop lies outside the source screenshot")
    if r <= l or b <= t:
        raise RuntimeError("Invalid crop")

    resolved_mode = args.mode

    if args.corner_radius is not None:
        fitted_radius = max(0, int(args.corner_radius))
    elif explicit:
        # Fit radius against the supplied exact geometry.
        _, _, grad = transition_maps(rgb)
        fitted_radius, _ = fit_corner_radius(grad, crop)
    else:
        fitted_radius = int(analysis["candidates"][0]["corner_radius"])

    if resolved_mode == "auto":
        # Tiny fitted radii are normally rasterisation artefacts on a square
        # rectangle rather than a deliberate rounded corner.
        resolved_mode = "rectangle" if fitted_radius <= 4 else "rounded-card"

    radius = 0 if resolved_mode in {"rectangle", "flood"} else fitted_radius

    element, mask, crop = crop_mask_and_image(
        source,
        resolved_mode,
        crop,
        radius,
        args.threshold,
    )
    result, padding, shadow_alpha = render_with_shadow(
        element,
        mask,
        blur=args.shadow_radius,
        offset_x=args.shadow_x,
        offset_y=args.shadow_y,
        opacity=args.shadow_opacity,
    )

    checks = internal_verify(
        source,
        result,
        crop,
        mask,
        padding,
        shadow_alpha,
        (args.shadow_x, args.shadow_y),
        args.shadow_radius,
        resolved_mode,
        radius,
        args.content_bounds,
    )

    mask_path = sidecar(args.output, ".mask.png")
    manifest_path = sidecar(args.output, ".manifest.json")
    mask_path.parent.mkdir(parents=True, exist_ok=True)
    mask.save(mask_path, "PNG")

    failures = [name for name, test in checks["tests"].items() if not test["pass"]]
    review_candidate = args.review_boundary and failures == ["geometry_follows_source_boundary"]
    manifest = {
        "version": VERSION,
        "pass": bool(checks["pass"]),
        "automated_pass": bool(checks["pass"]),
        "visual_review_required": True,
        "release_status": "needs-user-review" if review_candidate else ("automated-pass" if checks["pass"] else "rejected"),
        "boundary_review_requested": bool(args.review_boundary),
        "boundary_colour_evidence": boundary_colour_evidence(rgb, crop, radius) if args.review_boundary else None,
        "source_sha256": source_hash,
        "source_size": list(source.size),
        "mode": resolved_mode,
        "crop": list(crop),
        "corner_radius": int(radius),
        "content_bounds": list(args.content_bounds) if args.content_bounds else None,
        "boundary_kind": "chosen-container" if resolved_mode == "dark-container" else "source-surface",
        "geometry_confidence": float(geometry_confidence),
        "element_size": list(element.size),
        "output_size": list(result.size),
        "padding": int(padding),
        "shadow": {
            "radius": int(args.shadow_radius),
            "offset_x": int(args.shadow_x),
            "offset_y": int(args.shadow_y),
            "opacity": int(args.shadow_opacity),
        },
        "mask_file": mask_path.name,
        "analysis_file": analysis_json.name,
        "internal_verification": checks,
    }
    save_json(manifest_path, manifest)

    if not checks["pass"] and not review_candidate:
        raise RuntimeError(
            f"Internal verification failed. See {manifest_path}; no final PNG was written."
        )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    pnginfo = PngImagePlugin.PngInfo()
    pnginfo.add_text(GENERATED_TAG, "1")
    pnginfo.add_text("ui_element_trimmer_version", VERSION)
    pnginfo.add_text("release_status", manifest["release_status"])
    pnginfo.add_text("source_sha256", source_hash)
    pnginfo.add_text("crop", ",".join(str(v) for v in crop))
    pnginfo.add_text("corner_radius", str(radius))
    result.save(args.output, "PNG", pnginfo=pnginfo, optimize=True)

    print(f"Saved:     {args.output}")
    print(f"Manifest:  {manifest_path}")
    print(f"Mask:      {mask_path}")
    print(f"Analysis:  {analysis_png}")
    print(f"Geometry:  crop={crop} radius={radius} mode={resolved_mode}")
    print("Internal verification: BOUNDARY UNCERTAIN; candidate for user review" if review_candidate else "Internal verification: PASS")


if __name__ == "__main__":
    main()
