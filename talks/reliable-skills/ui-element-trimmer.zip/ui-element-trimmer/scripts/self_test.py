#!/usr/bin/env python3
"""Regression tests for UI Element Trimmer.

Covers geometry selection, exact-boundary rejection, transparent padding,
all-sided shadow coverage and fade, visible-border preservation, deliberately
broken old-style shadow rejection, per-side crop-error rejection, near-edge captures
and irregular flood mode.
"""
from __future__ import annotations

import json
import random
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, PngImagePlugin

from trim_ui_element import geometry_alignment_metrics

ROOT = Path(__file__).resolve().parent
TRIM = ROOT / "trim_ui_element.py"
VERIFY = ROOT / "verify_ui_element.py"
GENERATED_TAG = "ui_element_trimmer_generated"


def run(*args: str) -> None:
    subprocess.run([sys.executable, *args], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def expect_fail(*args: str) -> None:
    result = subprocess.run([sys.executable, *args], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if result.returncode == 0:
        raise AssertionError(f"Expected failure but command passed: {' '.join(args)}")


def noisy_background(size: tuple[int, int], colour: tuple[int, int, int]) -> Image.Image:
    im = Image.new("RGB", size, colour)
    draw = ImageDraw.Draw(im)
    random.seed(7)
    for _ in range(35):
        x = random.randint(0, size[0] - 80)
        y = random.randint(0, size[1] - 8)
        c = tuple(max(0, min(255, v + random.randint(-35, 35))) for v in colour)
        draw.rectangle((x, y, x + random.randint(18, 95), y + 3), fill=c)
    return im


def add_card(
    base: Image.Image,
    box: tuple[int, int, int, int],
    radius: int,
    fill: tuple[int, int, int],
    divider: int | None = None,
) -> Image.Image:
    x1, y1, x2, y2 = box
    sh = Image.new("RGBA", base.size, (0, 0, 0, 0))
    sd = ImageDraw.Draw(sh)
    sd.rounded_rectangle((x1, y1 + 3, x2 - 1, y2 + 2), radius=radius, fill=(0, 0, 0, 70))
    sh = sh.filter(ImageFilter.GaussianBlur(6))
    out = Image.alpha_composite(base.convert("RGBA"), sh).convert("RGB")
    d = ImageDraw.Draw(out)
    d.rounded_rectangle((x1, y1, x2 - 1, y2 - 1), radius=radius, fill=fill)
    if divider is not None:
        dx = x1 + divider
        d.line((dx, y1 + max(1, radius), dx, y2 - max(1, radius)), fill=(110, 110, 110), width=2)
    ink = (70, 70, 70) if sum(fill) > 380 else (220, 220, 220)
    for yy in range(y1 + 45, y2 - 25, 42):
        d.rectangle((x1 + 35, yy, min(x2 - 30, x1 + 150), yy + 5), fill=ink)
    return out


def add_bordered_card(
    base: Image.Image,
    box: tuple[int, int, int, int],
    radius: int,
    border: tuple[int, int, int],
    fill: tuple[int, int, int],
) -> Image.Image:
    """Synthetic analogue of a light Microsoft-style modal on a grey page."""
    x1, y1, x2, y2 = box
    sh = Image.new("RGBA", base.size, (0, 0, 0, 0))
    sd = ImageDraw.Draw(sh)
    sd.rounded_rectangle((x1, y1 + 3, x2 - 1, y2 + 2), radius=radius, fill=(0, 0, 0, 70))
    sh = sh.filter(ImageFilter.GaussianBlur(6))
    out = Image.alpha_composite(base.convert("RGBA"), sh).convert("RGB")
    d = ImageDraw.Draw(out)
    d.rounded_rectangle((x1, y1, x2 - 1, y2 - 1), radius=radius, fill=border)
    d.rounded_rectangle((x1 + 1, y1 + 1, x2 - 2, y2 - 2), radius=max(0, radius - 1), fill=fill)
    # Add internal structure so internal dividers cannot win geometry detection.
    d.rectangle((x1 + 226, y1 + 1, x1 + 227, y2 - 2), fill=(235, 235, 235))
    d.rounded_rectangle((x1 + 252, y1 + 140, x2 - 32, y2 - 60), radius=8, outline=(220, 220, 220), width=1, fill=(255, 255, 255))
    return out


def assert_shadow_and_transparency(output: Path, manifest: dict) -> None:
    with Image.open(output) as im:
        arr = np.asarray(im.convert("RGBA"), dtype=np.uint8)
    alpha = arr[:, :, 3]
    pad = int(manifest["padding"])
    ew, eh = [int(v) for v in manifest["element_size"]]
    l, t, r, b = pad, pad, pad + ew, pad + eh
    xa, xb = l + max(4, ew // 8), r - max(4, ew // 8)
    ya, yb = t + max(4, eh // 8), b - max(4, eh // 8)
    checks = {
        "top": np.any(alpha[max(0, t - 3):t, xa:xb] > 0),
        "bottom": np.any(alpha[b:min(alpha.shape[0], b + 3), xa:xb] > 0),
        "left": np.any(alpha[ya:yb, max(0, l - 3):l] > 0),
        "right": np.any(alpha[ya:yb, r:min(alpha.shape[1], r + 3)] > 0),
    }
    if not all(checks.values()):
        raise AssertionError(f"Shadow missing on one or more sides: {checks}")
    if not (
        np.all(alpha[:4, :] == 0)
        and np.all(alpha[-4:, :] == 0)
        and np.all(alpha[:, :4] == 0)
        and np.all(alpha[:, -4:] == 0)
    ):
        raise AssertionError("Transparent guard band is not clean")
    if not np.all(arr[:, :, :3][alpha == 0] == 0):
        raise AssertionError("Transparent pixels retain hidden source RGB")


def verify_case(work: Path, name: str, source: Path, expected_crop: tuple[int, int, int, int], mode: str) -> tuple[Path, dict]:
    output = work / f"{name}_out.png"
    run(str(TRIM), str(source), str(output), "--mode", mode)
    manifest_path = output.with_name(output.stem + ".manifest.json")
    manifest = json.loads(manifest_path.read_text())
    got = tuple(int(v) for v in manifest["crop"])
    if max(abs(a - b) for a, b in zip(got, expected_crop)) > 1:
        raise AssertionError(f"{name}: crop {got} != expected {expected_crop}")
    qa = work / f"{name}_qa"
    run(str(VERIFY), "--source", str(source), "--output", str(output), "--manifest", str(manifest_path), "--qa-dir", str(qa))
    report = json.loads((qa / "verification.json").read_text())
    if not report.get("pass"):
        raise AssertionError(f"{name}: verifier failed")
    if not report.get("visual_review_required"):
        raise AssertionError(f"{name}: verifier did not mark visual review as mandatory")
    if not report["tests"].get("straight_edge_source_fidelity", {}).get("pass"):
        raise AssertionError(f"{name}: outer border fidelity was not verified")
    if not (qa / "qa_source_boundary.png").exists():
        raise AssertionError(f"{name}: source-boundary QA image was not created")
    assert_shadow_and_transparency(output, manifest)
    return output, manifest


def make_old_style_broken_shadow(good_output: Path, manifest: dict, destination: Path) -> None:
    """Recreate the v3 failure: blur an element-sized mask before padding."""
    mask_path = good_output.with_name(manifest["mask_file"])
    with Image.open(good_output) as im:
        good = im.convert("RGBA")
        info = dict(im.info)
    with Image.open(mask_path) as im:
        mask = im.convert("L")
    pad = int(manifest["padding"])
    ew, eh = [int(v) for v in manifest["element_size"]]
    shadow = manifest["shadow"]
    blur = int(shadow["radius"])
    ox, oy = int(shadow["offset_x"]), int(shadow["offset_y"])
    opacity = int(shadow["opacity"])

    element = good.crop((pad, pad, pad + ew, pad + eh))
    clipped_alpha = mask.filter(ImageFilter.GaussianBlur(blur)).point(lambda px: int(round(px * opacity / 255.0)))
    clipped_shadow = Image.new("RGBA", (ew, eh), (0, 0, 0, 255))
    clipped_shadow.putalpha(clipped_alpha)
    bad = Image.new("RGBA", good.size, (0, 0, 0, 0))
    bad.alpha_composite(clipped_shadow, (pad + ox, pad + oy))
    bad.alpha_composite(element, (pad, pad))
    arr = np.asarray(bad, dtype=np.uint8).copy()
    arr[arr[:, :, 3] == 0, :3] = 0
    bad = Image.fromarray(arr, "RGBA")

    pnginfo = PngImagePlugin.PngInfo()
    for key, value in info.items():
        if isinstance(value, str):
            pnginfo.add_text(key, value)
    pnginfo.add_text(GENERATED_TAG, "1")
    bad.save(destination, "PNG", pnginfo=pnginfo)


def main() -> None:
    with tempfile.TemporaryDirectory(prefix="ui-element-trimmer-") as td:
        work = Path(td)
        size = (700, 480)
        cases = [
            ("light", (90, 94, 100), (32, 28, 666, 452), 18, (246, 246, 246), 180, "rounded-card"),
            ("dark", (228, 230, 233), (55, 40, 640, 430), 14, (42, 44, 48), 200, "rounded-card"),
            ("square", (115, 120, 128), (70, 60, 620, 420), 0, (250, 250, 250), 170, "rectangle"),
            ("near_edge", (70, 75, 80), (2, 2, 698, 478), 22, (245, 245, 245), 220, "rounded-card"),
            ("nested", (130, 132, 136), (25, 24, 675, 455), 20, (248, 248, 248), 210, "rounded-card"),
        ]
        first_good: tuple[Path, dict, Path] | None = None
        for name, bg, box, radius, fill, divider, mode in cases:
            im = noisy_background(size, bg)
            im = add_card(im, box, radius, fill, divider)
            if name == "nested":
                d = ImageDraw.Draw(im)
                d.rectangle((250, 80, 620, 400), outline=(0, 0, 0), width=3)
                d.line((250, 180, 620, 180), fill=(0, 0, 0), width=3)
            src = work / f"{name}.png"
            im.save(src)
            output, manifest = verify_case(work, name, src, box, mode)
            if first_good is None:
                first_good = (output, manifest, src)

        # Microsoft-style bordered modal with dimensions similar to the real
        # screenshot that exposed the v3 clipped-shadow bug.
        ms_size = (830, 679)
        ms_box = (10, 7, 810, 665)
        ms = Image.new("RGB", ms_size, (128, 128, 128))
        ms = add_bordered_card(ms, ms_box, 24, (255, 255, 255), (242, 242, 242))
        ms_src = work / "m365_like.png"
        ms.save(ms_src)
        verify_case(work, "m365_like", ms_src, ms_box, "rounded-card")

        # Every one-pixel crop error, on every side, must fail geometry review.
        # This directly protects against the "tight on one side" failure mode.
        # Check all eight variants directly, then run two end-to-end negative
        # subprocess tests so the explicit-crop rejection path is also covered.
        l, t, r, b = ms_box
        wrong_crops = {
            "left_in": (l + 1, t, r, b),
            "right_in": (l, t, r - 1, b),
            "top_in": (l, t + 1, r, b),
            "bottom_in": (l, t, r, b - 1),
            "left_out": (l - 1, t, r, b),
            "right_out": (l, t, r + 1, b),
            "top_out": (l, t - 1, r, b),
            "bottom_out": (l, t, r, b + 1),
        }
        ms_rgb = np.asarray(ms.convert("RGB"), dtype=np.uint8)
        for wrong_name, wrong_crop in wrong_crops.items():
            metrics = geometry_alignment_metrics(ms_rgb, wrong_crop, 24, "rounded-card")
            if metrics.get("pass"):
                raise AssertionError(f"Geometry accepted one-pixel error {wrong_name}: {metrics}")
        for wrong_name in ("left_in", "right_out"):
            wrong_crop = wrong_crops[wrong_name]
            wrong = work / f"wrong_crop_{wrong_name}.png"
            expect_fail(
                str(TRIM), str(ms_src), str(wrong), "--mode", "rounded-card",
                "--crop", ",".join(str(v) for v in wrong_crop),
                "--corner-radius", "24",
            )

        # Recreate the old v3 clipped-shadow defect and prove the independent
        # verifier rejects it.
        if first_good is None:
            raise AssertionError("No baseline case produced")
        good_output, good_manifest, good_source = first_good
        broken = work / "broken_old_shadow.png"
        make_old_style_broken_shadow(good_output, good_manifest, broken)
        broken_manifest = good_output.with_name(good_output.stem + ".manifest.json")
        expect_fail(
            str(VERIFY), "--source", str(good_source), "--output", str(broken),
            "--manifest", str(broken_manifest), "--qa-dir", str(work / "broken_qa"),
        )

        # Dark-mode button and label must remain inside one opaque rounded container.
        im = Image.new("RGB", (90, 100), (44, 44, 46))
        d = ImageDraw.Draw(im)
        d.rounded_rectangle((25, 20, 60, 55), radius=7, fill=(80, 80, 80))
        d.rectangle((29, 64, 58, 70), fill=(190, 190, 190))
        src = work / "dark_container.png"
        im.save(src)
        output = work / "dark_container_out.png"
        run(str(TRIM), str(src), str(output), "--mode", "dark-container",
            "--crop", "15,10,71,81", "--content-bounds", "25,20,61,71", "--corner-radius", "8")
        mp = output.with_name(output.stem + ".manifest.json")
        manifest = json.loads(mp.read_text())
        qa = work / "dark_container_qa"
        run(str(VERIFY), "--source", str(src), "--output", str(output), "--manifest", str(mp), "--qa-dir", str(qa))
        with Image.open(output) as oi:
            a = np.asarray(oi)
        pad = manifest["padding"]
        # Background gap between the button and label stays opaque and unmodified.
        assert tuple(a[pad+49, pad+25]) == (44, 44, 46, 255)
        assert_shadow_and_transparency(output, manifest)
        for invalid_args in [
            ["--crop", "15,10,71,81", "--corner-radius", "8"],
            ["--crop", "24,19,62,72", "--content-bounds", "25,20,61,71", "--corner-radius", "8"],
            ["--crop", "22,17,64,74", "--content-bounds", "25,20,61,71", "--corner-radius", "20"],
        ]:
            expect_fail(str(TRIM), str(src), str(work / "bad_container.png"), "--mode", "dark-container", *invalid_args)
        # Independent verifier must reject a forged container mask.
        mask_path = output.with_name(manifest["mask_file"])
        with Image.open(mask_path) as mi:
            original_mask = mi.copy()
        bad_mask = original_mask.copy()
        ImageDraw.Draw(bad_mask).rectangle((20, 40, 30, 50), fill=0)
        bad_mask.save(mask_path)
        expect_fail(str(VERIFY), "--source", str(src), "--output", str(output), "--manifest", str(mp), "--qa-dir", str(work / "bad_container_qa"))
        original_mask.save(mask_path)

        # Blurred light-on-light shape: boundary-only uncertainty may be reviewed.
        im = Image.new("RGB", (280, 180), (248, 248, 248))
        d = ImageDraw.Draw(im)
        d.rounded_rectangle((30, 30, 229, 129), radius=20, fill=(238, 238, 238))
        d.text((85, 70), "Home", fill=(40, 40, 40))
        im = im.filter(ImageFilter.GaussianBlur(3))
        src = work / "uncertain_light.png"
        im.save(src)
        output = work / "uncertain_light_review.png"
        args = [str(TRIM), str(src), str(output), "--mode", "rounded-card",
                "--crop", "30,30,230,130", "--corner-radius", "20"]
        expect_fail(*args)
        run(*args, "--review-boundary")
        mp = output.with_name(output.stem + ".manifest.json")
        manifest = json.loads(mp.read_text())
        assert manifest["automated_pass"] is False
        assert manifest["release_status"] == "needs-user-review"
        assert manifest["boundary_colour_evidence"]["source_only"] is True
        qa = work / "uncertain_light_qa"
        expect_fail(str(VERIFY), "--source", str(src), "--output", str(output), "--manifest", str(mp), "--qa-dir", str(qa))
        report = json.loads((qa / "verification.json").read_text())
        assert report["pass"] is False and report["review_eligible"] is True
        assert_shadow_and_transparency(output, manifest)
        # Review does not bypass missing all-sided shadow or clipped source bounds.
        expect_fail(*args, "--review-boundary", "--shadow-radius", "0")
        expect_fail(str(TRIM), str(src), str(output), "--mode", "rounded-card",
                    "--crop", "0,0,230,130", "--corner-radius", "20", "--review-boundary")

        # Irregular flood mode with explicit search crop.
        im = Image.new("RGB", (320, 220), (80, 84, 88))
        d = ImageDraw.Draw(im)
        d.rounded_rectangle((80, 60, 250, 150), radius=20, fill=(245, 245, 245))
        d.polygon([(120, 148), (140, 148), (125, 175)], fill=(245, 245, 245))
        src = work / "irregular.png"
        im.save(src)
        output = work / "irregular_out.png"
        run(str(TRIM), str(src), str(output), "--mode", "flood", "--crop", "60,40,270,190", "--threshold", "20")
        manifest = output.with_name(output.stem + ".manifest.json")
        qa = work / "irregular_qa"
        run(str(VERIFY), "--source", str(src), "--output", str(output), "--manifest", str(manifest), "--qa-dir", str(qa))

    print("UI Element Trimmer regression suite: PASS")


if __name__ == "__main__":
    main()
